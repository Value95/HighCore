﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneHelp : MonoBehaviour
{
    private static SceneHelp instance;
    public static SceneHelp GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<SceneHelp>();

            if (instance == null)
            {
                GameObject container = new GameObject("SceneHelp");

                instance = container.AddComponent<SceneHelp>();
            }
        }
        return instance;
    }

    public PlayerState state;

    [HideInInspector] public float hp;
    [HideInInspector] public float stamina;

    public Slider sHp;
    public Slider sStamina;

    private void Awake()
    {
        DontDestroyOnLoad(gameObject);

        hp = state.hp.value;
        stamina = state.Stamina.value;


    }

    // Update is called once per frame
    void Update()
    {
        if (!state)
        {
            sHp = GameObject.Find("HP").gameObject.GetComponent<Slider>();
            sStamina = GameObject.Find("Stamina").gameObject.GetComponent<Slider>();
            sHp.value = hp;
            sStamina.value = stamina;
            StaminaEffectOnOff();
            state = GameObject.Find("Player").transform.GetChild(0).transform.GetComponent<PlayerState>();
        }

        hp = state.hp.value;
        stamina = state.Stamina.value;

        if (hp <= 0)
        {
            hp = state.hp.maxValue;
        }
    }

    void StaminaEffectOnOff()
    {
        if (sStamina.value == sStamina.maxValue)
        {
            sStamina.transform.GetChild(0).gameObject.SetActive(true);
        }
        else
        {
            sStamina.transform.GetChild(0).gameObject.SetActive(false);
        }
    }
}
