﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class LoadingSceneManager : MonoBehaviour
{
    bool IsDone = false;
    AsyncOperation async_operation;
    public string Next_View;
    public bool update;
    public bool keyOn;

    public Slider slider;
    public Animator anim;
    public GameObject effect;
    private void Awake()
    {
    }

    private void Start()
    {
        Screen.SetResolution(1280, 720, true);
        Application.targetFrameRate = 60;
        //StartCoroutine(StartLoad(Next_View));
    }

    void Update()
    {
        if (update)
        {
            slider.value += Time.deltaTime;
            if (slider.value >= slider.maxValue)
            {
                update = false;
                Application.LoadLevel(Next_View);
            }
        }

        if(Input.GetKeyDown(KeyCode.End))
        {
            Application.LoadLevel(Next_View);

        }

        if (keyOn)
        {
            if (Input.GetKeyDown(KeyCode.Return))
            {
                NextScene();
                keyOn = false;
            }
        }
    }

    public IEnumerator StartLoad(string strSceneName)
    {
        async_operation = Application.LoadLevelAsync(strSceneName);
        async_operation.allowSceneActivation = false;

        if (IsDone == false)
        {
            IsDone = true;

            while (async_operation.progress < 0.9f)
            {
                yield return true;
            }
        }
    }

    public void NextScene()
    {
        update = true;
        anim.Play("Fade");
        UI_SoundManage.GetInstance().UI_EnterSound();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            anim.Play("Fade");
            update = true;
            effect.SetActive(false);
            
        }
    }
}