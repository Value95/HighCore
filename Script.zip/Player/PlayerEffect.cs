﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerEffect : MonoBehaviour
{
    public ParticleSystem healingEffect;
    public ParticleSystem skillEffect;
    public ParticleSystem attackEffect;

}
