﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttackAnimEvent : MonoBehaviour
{
    public AttackManage attackMG;
    public PlayerAttack attack;
    public PlayerUpperCut upperCut;
    public PlayerFSM fsm;
    PlayerState state;

    float force;
    bool moveStart;

    public void Start()
    {
        state = transform.GetChild(0).GetComponent<PlayerState>();
        moveStart = false;
    }

    private void Update()
    {
        if (moveStart)
        {
            if(fsm._CurrentState == Player_State.Damaged)
            {
                force = 0;
            }

            if (this.transform.rotation.y == 0 && HelpEvent.GetInstance().MoveCorrection(Vector2.right, this.transform.position, 0.8f))
            {
                this.transform.position += Vector3.right * force * Time.deltaTime;
            }
            else if (this.transform.rotation.y == 1 && HelpEvent.GetInstance().MoveCorrection(Vector2.left, this.transform.position, 0.8f))
            {
                this.transform.position += Vector3.left * force * Time.deltaTime;
            }
        }
    }

    public void AttackStart() // 판정이 켜져있는시간
    {
        attackMG.attackHitCollider.SetActive(true);
        attack.attackCheck = false;

        Cha_SoundManage.GetInstance().Cha_AttackSound();
    }

    public void AttackEnd() // 판정을끄면서 대미지를넣는다.
    {
        if(attackMG.AttackHit(state.attackDamage))
        {
            Mo_SoundManage.GetInstance().Mo_HitSound();
        }

        attackMG.attackHitCollider.SetActive(false);
        if (!attack.attackCheck)
        {
            attack.AttackEnd();
        }
        moveStart = false;
    }

    //바라보는방향으로 앞으로가기
    void AttackMove(float force)
    {
        this.force = force;
        moveStart = true;
    }

    public void UpperCutStart()
    {
        attackMG.attackHitCollider.SetActive(true);
        Cha_SoundManage.GetInstance().Cha_UpperCutSound();
        force = 0;
    }

    public void UpperCutEnd()
    {
        attackMG.attackHitCollider.SetActive(false);
        if (attackMG.AttackHit(state.attackDamage))
        {
            Mo_SoundManage.GetInstance().Mo_HitSound();
        }
        upperCut.UpperCutEnd();
    }

    public void AirBorne()
    {
        attackMG.AirBorne();
    }

    public void SkillStart()
    {
        attackMG.attackHitCollider.SetActive(true);
        force = 0;
    }

    public void SkillEnd()
    {
        attackMG.attackHitCollider.SetActive(false);
        if (attackMG.AttackHit(state.skillDamage))
        {
            Mo_SoundManage.GetInstance().Mo_HitSound();
        }
    }

    public void ListHitObjClear() 
    {
        attackMG.listHitObj.Clear();
    }
}
