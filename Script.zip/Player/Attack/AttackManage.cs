﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackManage : MonoBehaviour
{
    public List<GameObject> listHitObj = new List<GameObject>();
    public PlayerState state;
    public PlayerFSM fsm;
    public GameObject attackHitCollider;
    

    bool deathon = false;

    public bool AttackHit(int damage)
    {
        bool hiton =false;

        foreach (var hitObj in listHitObj) // 대미지넣어주는부분
        {
            if (hitObj)
            {
                hitObj.GetComponent<HP>().HpDown(damage);
                Camera.main.GetComponent<CameraMove>().CameraShake(0.6f, 0.05f);

                EffectCase(hitObj);

                PlayerUIMangaer.GetInstance().ComoboUI_On();

                if (hitObj.GetComponent<HP>().hp <= 0)
                {
                    deathon = true;
                }
                hiton = true;
            }
        }
           

        if (deathon && state.skillCount < fsm.state.skillMaxCount) //죽으면 일섬게이지 충전
        {
            state.SkillCountUp();
            deathon = false;
        }

        if(hiton)
            state.Stamina.value += 1;

        listHitObj.Clear();
        return hiton;
    }

    public void AirBorne()
    {
        foreach (var hitObj in listHitObj)
        {
            if (fsm._CurrentState == Player_State.UpperCut)
            {
                if (hitObj.gameObject.layer == 16)
                {
                    MonsterHelp.Airburn(hitObj, fsm.state.jumpForce);
                }
            }
        }
    }

    void EffectCase(GameObject target)
    {
        switch (fsm._CurrentState)
        {
            case Player_State.UpperCut:
                break;
            case Player_State.Attack:
                fsm.effect.attackEffect.Play();
                break;
            case Player_State.Skill:
                target.GetComponent<EffectList>().damagedSkill.Play();
                break;
        }
    }

    void ColliderFalse()
    {
        attackHitCollider.SetActive(false);
    }
}

