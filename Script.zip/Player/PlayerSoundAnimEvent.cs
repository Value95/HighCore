﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSoundAnimEvent : MonoBehaviour
{
    public void MoveSound()
    {
        Cha_SoundManage.GetInstance().Cha_MoveSound();
    }

    public void DamagedSound()
    {
        Cha_SoundManage.GetInstance().Cha_DamagedSound();
    }

    public void JumpSound()
    {
        Cha_SoundManage.GetInstance().Cha_JumpUpSound();
        Cha_SoundManage.GetInstance().Cha_JumpSound();
    }

    public void JumpDonwSound()
    {
        Cha_SoundManage.GetInstance().Cha_JumpDownSound();
    }

    public void HealingSound()
    {
        Cha_SoundManage.GetInstance().Cha_HealingSound();
    }

    public void SkillSound()
    {
        Cha_SoundManage.GetInstance().Cha_SkillSound();
    }

    public void ThornDamagedSound()
    {
        Cha_SoundManage.GetInstance().Cha_ThornDamagedSound();
    }

}
