﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerState : MonoBehaviour
{
    PlayerFSM fsm;

    public float warkSpeed;
    public float jumpForce;
    public float upperCutSpeed;
    public float skillSpeed;

    public Slider hp;
    public Slider Stamina; //스태미너

    public int skillMaxCount;
    [HideInInspector] public int skillCount; // 질풍참 남은횟수
    public float skillCoolingTimeMax;

    [HideInInspector] public float skillCoolingTime; // 질풍참 쿨탐

    public int attackDamage;
    public int skillDamage;

    public float healingAdd;

    [HideInInspector] public bool stop;

    // Start is called before the first frame update
    void Start()
    {
        fsm = this.transform.GetComponent<PlayerFSM>();
        hp.value = SceneHelp.GetInstance().hp;
        Stamina.value = SceneHelp.GetInstance().stamina;
        stop = true;
        skillCoolingTime = skillCoolingTimeMax;
        skillCount = skillMaxCount;
    }

    // Update is called once per frame
    void Update()
    {
        skillCoolingTimeDown();
        StaminaEffectOnOff();

        if (Input.GetKeyDown(KeyCode.PageUp))
        {
            skillDamage *= 2;
        }
        else if (Input.GetKeyDown(KeyCode.PageDown))
        {
            skillDamage /= 2;
        }
        //else if(Input.GetKeyDown(KeyCode.Home))
        //{
        //    skillCoolingTimeMax = 0;
        //}
    }

    public void HpDown(float damage)
    {
        if (!fsm.invincibility)
        {
            hp.value -= damage;
            fsm.ChScript(Player_State.Damaged);
        }
    }

    void skillCoolingTimeDown()
    {
        // 카운트가 3이아니면
        //쿨타임새고 다되면 카운트1추가
        if (skillCount < skillMaxCount)
        {
            skillCoolingTime -= Time.deltaTime;

            if (skillCoolingTime <= 0)
            {
                SkillCountUp();
                skillCoolingTime = skillCoolingTimeMax;
            }
        }
    }

    //skill ui증가
    public void SkillCountUp()
    {
        PlayerUIMangaer.GetInstance().skillUI[skillCount].SetActive(true);
        PlayerUIMangaer.GetInstance().skillUI[skillCount].transform.GetChild(0).transform.GetComponent<ParticleSystem>().Play();
        skillCount++;
    }

    public void SkillCountDown()
    {
        skillCount--;
        PlayerUIMangaer.GetInstance().skillUI[skillCount].SetActive(false);
    }

    void StaminaEffectOnOff()
    {
        if(Stamina.value == Stamina.maxValue && stop)
        {
            Stamina.transform.GetChild(0).gameObject.SetActive(true);
        }
        else
        {
            Stamina.transform.GetChild(0).gameObject.SetActive(false);
        }
    }
}


