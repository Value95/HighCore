﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerUpperCut : FSMState
{
    public Vector2 boxSize;

    public override void BeginState()
    {
        _manager.hitBox2D.size = boxSize;

        if (!_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("UpperCut") && !_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("AirAttack"))
        {
            _manager.invincibility = true;
            _manager.rigidbody.constraints = RigidbodyConstraints2D.FreezeAll;
            _manager.anim.SetInteger("Fsm", (int)Player_State.UpperCut);
            _manager.move.moveOn = false;
        }
        else
            UpperCutEnd();
    }

    public override void EndState()
    {
        _manager.move.moveOn = true;
        _manager.invincibility = false;
    }

    private void Update()
    {
        transform.parent.transform.position += Vector3.up * _manager.state.upperCutSpeed * Time.deltaTime;
    }

    public void UpperCutEnd()
    {
        _manager.ChScript(Player_State.Idle);
    }
}
