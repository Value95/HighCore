﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class PlayerDeath : FSMState
{

    public override void BeginState()
    {
        _manager.invincibility = true;
        _manager.anim.SetInteger("Fsm", (int)Player_State.Death);
        _manager.move.moveOn = false;
        _manager.rigidbody.constraints = RigidbodyConstraints2D.None;
    }

    // Update is called once per frame
    void Update()
    {
        if(_manager.move.groundChack && !_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Cha_Ani_Death"))
            _manager.anim.Play("Cha_Ani_Death");

        if (_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Cha_Ani_Death"))
        {
            if (_manager.anim.GetCurrentAnimatorStateInfo(0).normalizedTime > 1.5f)
            {
                Application.LoadLevel(SceneManager.GetActiveScene().name);
            }
        }
    }
}
