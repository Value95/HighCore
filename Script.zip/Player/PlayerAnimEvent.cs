﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimEvent : MonoBehaviour
{
    public GameObject player;

    void PlayerOn()
    {
        player.SetActive(true);
    }

    void TimeLineOff()
    {
        Destroy(this.gameObject);
    }

    void CameraShack()
    {
        Camera.main.GetComponent<CameraMove>().CameraShake(1.5f, 0.2f);
    }

}
