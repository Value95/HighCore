﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerUIController : MonoBehaviour
{
    [HideInInspector] public bool stop;
    // Start is called before the first frame update
    void Start()
    {
        stop = true;
    }

    // Update is called once per frame
    void Update()
    {
        DamagedCemaraOnOff();
    }

    void DamagedCemaraOnOff()
    {
        float percentage = PlayerUIMangaer.GetInstance().state.hp.maxValue - ((PlayerUIMangaer.GetInstance().state.hp.maxValue * 70) / 100);

        if (PlayerUIMangaer.GetInstance().state.hp.value <= percentage && stop)
        {
            PlayerUIMangaer.GetInstance().damagedCameraAnim.Play("Damaged_Camera_On");
        }
        else
            PlayerUIMangaer.GetInstance().damagedCameraAnim.Play("Damaged_Camera_Off");
    }
}
