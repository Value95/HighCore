﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialGuide : MonoBehaviour
{
    public Vector3 boxSize;
    public PlayerFSM playerfsm;
    public GameObject radioBox;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Collider2D[] cols = Physics2D.OverlapBoxAll(this.transform.position, boxSize, 0);

        foreach (Collider2D col in cols)
        {
            if (col.transform.tag == "Player")
            {
                if(GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Base Layer.Healing") == true)
                {
                    StartCoroutine("TutoRadio3rd");
                }
            }
        }
    }
    void OnDrawGizmos()
    {
        Gizmos.matrix = transform.localToWorldMatrix;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(Vector3.zero, boxSize);
    }

    IEnumerator TutoRadio3rd()
    {
        yield return new WaitForSeconds(1.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(6.2f);
        radioBox.SetActive(false);
        yield return new WaitForSeconds(1.0f);
        GameObject.Find("LoadScene").gameObject.transform.position = new Vector3(-108.0f, -7.5f, 0);
        this.gameObject.SetActive(false);
    }
}
