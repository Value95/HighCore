﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerUIMangaer : MonoBehaviour
{
    private static PlayerUIMangaer instance;
    public static PlayerUIMangaer GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<PlayerUIMangaer>();

            if (instance == null)
            {
                GameObject container = new GameObject("PlayerUIMangaer");

                instance = container.AddComponent<PlayerUIMangaer>();
            }
        }
        return instance;
    }

    public PlayerState state;

    public Animator damagedCameraAnim;
    public Animator hitDamagedCameraAnim;


    [HideInInspector] public List<GameObject> skillUI = new List<GameObject>();

    public GameObject comboObj;
    public List<Animator> comboCountUI = new List<Animator>();
    [HideInInspector] public float comboTimer;
    [HideInInspector] public bool comboUI_OnOff;

    [HideInInspector] public int comboCount;

    // Start is called before the first frame update
    void Start()
    {
        comboCount = 0;
        comboUI_OnOff = false;

        for (int i = 0; i < state.skillCount; i++)
        {
            skillUI[i] = GameObject.Find("Skill_" + i.ToString()).gameObject;
        }
    }

    // Update is called once per frame
    void Update()
    {
        ComboUI();
    }

    // 2초안에 데미지변화가없으면 ui삭제
    void ComboUI()
    {
        if (comboUI_OnOff) // UI생성 콤보수증가
        {
            comboTimer -= Time.deltaTime;

            if (comboTimer <= 0)
            {
                comboUI_OnOff = false;
                comboObj.SetActive(false);
                comboCount = 0;
                comboCountUI[0].Play("Font_Null");
                comboCountUI[1].Play("Font_Null");
                comboCountUI[2].Play("Font_Null");

            }
        }
    }

    void ComboCountUI()
    {
        // 숫자를비교해서 애니메이션 넘버값을넘겨준다.
        // 2번째 3번째는 0이면 빈오브젝트를보여준다.
        int[] number = new int[3];
        number[2] = comboCount / 100;
        number[1] = (comboCount % 100) / 10;
        number[0] = comboCount % 10;

        comboCountUI[0].Play("Font_" + number[0].ToString());

        if (comboCountUI[1].GetCurrentAnimatorStateInfo(0).nameHash != Animator.StringToHash("Base Layer.Font_" + number[1].ToString()))
        {
            if(number[2] == 0 && number[1] != 0) //2가 1이면 1은 상관없음 2가 0이면 1은 0일수없음
                comboCountUI[1].Play("Font_" + number[1].ToString());
            else if(number[2] != 0)
                comboCountUI[1].Play("Font_" + number[1].ToString());
        }
        if (number[2] != 0 && comboCountUI[2].GetCurrentAnimatorStateInfo(0).nameHash != Animator.StringToHash("Base Layer.Font_" + number[2].ToString()))
            comboCountUI[2].Play("Font_" + number[2].ToString());
    } // 3번째값이 1일때는 두번째값이 0이어도된다.

    public void ComoboUI_On()
    {
        if(!comboUI_OnOff)
        {
            comboObj.SetActive(true);
            comboUI_OnOff = true;
        }

        comboTimer = 2.0f;
        comboCount++;
        ComboCountUI();
    }

}


