﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManage : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        PauseGame();
    }

    public void CloseButton()
    {
        if(Time.timeScale == 0.0f)
        {
            transform.Find("Menu").gameObject.SetActive(false);
            Time.timeScale = 1.0f;
        }
    }

    public void ReStartButton()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void QuitButton()
    {
        Application.Quit();
    }

    public void SoundControl(bool soundOff)
    {
        if (!soundOff)
        {
            GameObject.Find("Audio Source").GetComponent<AudioListener>().enabled = true;
        }
        else if(soundOff)
        {
            GameObject.Find("Audio Source").GetComponent<AudioListener>().enabled = false;
        }
    }

    public void PauseGame()
    {

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (transform.Find("Menu").gameObject.activeSelf == false)
            {
                transform.Find("Menu").gameObject.SetActive(true);
                if(Time.timeScale == 1.0f)
                {
                    Time.timeScale = 0.0f;
                }
            }
            else if (transform.Find("Menu").gameObject.activeSelf == true)
            {
                transform.Find("Menu").gameObject.SetActive(false);
                if(Time.timeScale == 0.0f)
                {
                    Time.timeScale = 1.0f;
                }
            }
        }
    }
}
