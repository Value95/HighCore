﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyOffScreenIndicator : MonoBehaviour {
	private GameObject[] Arrow;
	private Vector3 v_diff;
	private float atan2;

	void Awake() {
		Arrow = GameObject.FindGameObjectsWithTag ("ScreenArrow");
	}

	void LateUpdate()
	{
		GameObject[] enemyTarget = GameObject.FindGameObjectsWithTag ("Monster");
		if (enemyTarget.Length > 0) {
			for (int i = 0; i < Arrow.Length; i++) {
				if (i < enemyTarget.Length) {
					//Rotate towards the enemy
					v_diff = (enemyTarget[i].transform.position - Arrow[i].transform.position);
					atan2 = Mathf.Atan2 (v_diff.y, v_diff.x);
					Arrow[i].transform.rotation = Quaternion.Euler (0f, 0f, atan2 * Mathf.Rad2Deg - 90);

					//Move Towards the target
					Arrow[i].transform.position = Vector3.MoveTowards (Arrow[i].transform.position, enemyTarget[i].transform.position, 1000);

					//Clamp to the screen view
					Vector3 pos = Camera.main.WorldToViewportPoint (Arrow[i].transform.position);
					pos.x = Mathf.Clamp01 (pos.x);
					pos.y = Mathf.Clamp01 (pos.y);
					Arrow[i].transform.position = Camera.main.ViewportToWorldPoint (pos) * 0.95f;

					float dis = Vector3.Distance (enemyTarget[i].transform.localPosition, Arrow[i].transform.localPosition);
					if (dis < 0.3f) {
						Arrow [i].SetActive (false);
					} else if (!Arrow [i].activeSelf) {
						Arrow [i].SetActive (true);
					}
				} else {
					Arrow [i].transform.position = Vector3.one * 100;
				}
			}
		}
	}
}
