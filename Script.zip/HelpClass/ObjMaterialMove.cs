﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//[ExecuteInEditMode]
public class ObjMaterialMove : MonoBehaviour
{
    Renderer thisRenderer;
    float textureOffsetX;
    [SerializeField]float addOffset;
    public float scroolSpeed;

    // Start is called before the first frame update
    void Start()
    {
        thisRenderer = this.GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {
        textureOffsetX += Time.deltaTime * scroolSpeed;
        thisRenderer.material.mainTextureOffset = new Vector2(textureOffsetX + addOffset, 0);
        if(textureOffsetX + addOffset >= 1)
        {
            textureOffsetX = 0;
        }
    }
}
