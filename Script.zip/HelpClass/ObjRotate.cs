﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum LF
{
    Left,
    Right
}

public class ObjRotate : MonoBehaviour
{
    public float rotateSpeed;

    public LF direction;
    float dir;
    // Start is called before the first frame update
    void Start()
    {
        switch(direction)
        {
            case LF.Left:
                dir = -1;
                break;
            case LF.Right:
                dir = 1;
                break;
        }
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.rotation = Quaternion.EulerRotation(0, 0, this.transform.eulerAngles.z + (rotateSpeed * dir));
    }
}
