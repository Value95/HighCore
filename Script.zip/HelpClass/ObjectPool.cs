﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectPool : MonoBehaviour
{
    private static ObjectPool instance;
    public static ObjectPool GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<ObjectPool>();

            if (instance == null)
            {
                GameObject container = new GameObject("HelpEvent");

                instance = container.AddComponent<ObjectPool>();
            }
        }
        return instance;
    }

    public List<GameObject> stone = new List<GameObject>();
    [HideInInspector] public int stoneListCount;

    public List<GameObject> thornList = new List<GameObject>();

    public List<GameObject> BBojjakList = new List<GameObject>();
    [HideInInspector] public int bbojjakListCount;
    public List<GameObject> CutieList = new List<GameObject>();
    [HideInInspector] public int cutieListCount;

    public List<GameObject> EliteThornList = new List<GameObject>();
    [HideInInspector] public int EliteThornListCount;

    // Start is called before the first frame update
    void Start()
    {
        bbojjakListCount = 0;
        cutieListCount = 0;
        EliteThornListCount = 0;
        stoneListCount = 0;
    }

    public int countAdd(int maxCount , int currentCount)
    {
        if (maxCount == currentCount)
            currentCount = 0;
        else
            currentCount++;

        return currentCount;
    }

    public GameObject BBojjakAdd(Vector3 pos)
    {
        BBojjakList[bbojjakListCount].transform.position = pos;
        BBojjakList[bbojjakListCount].SetActive(true);
        int count = bbojjakListCount;
        countAdd(BBojjakList.Count, bbojjakListCount);
        return BBojjakList[count];
    }

    public GameObject CutieAdd(Vector3 pos)
    {
        CutieList[cutieListCount].transform.position = pos;
        CutieList[cutieListCount].SetActive(true);
        int count = cutieListCount;
        countAdd(CutieList.Count, cutieListCount);
        return CutieList[count];
    }
}
