﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossAnimEvent : MonoBehaviour
{
    public BossPierce pierce;
    public BossThorn thorn;
    public List<GameObject> hitBox = new List<GameObject>();
    public List<ParticleSystem> effect = new List<ParticleSystem>();


    public void cutBoxOn(int num)
    {
        hitBox[num].SetActive(true);
        effect[num].Play();
    }

    public void warningOff(int num)
    {
        pierce.warning[num].SetActive(false);
    }

    public void ThornStart(int num)
    {
        thorn.ThornProduction(8, 0, 45, num);
        Boss_SoundManage.GetInstance().Boss_ThronSound();
    }

    public void cameraShake()
    {
        Camera.main.GetComponent<CameraMove>().CameraShake(0.5f, 0.3f);
    }
}
