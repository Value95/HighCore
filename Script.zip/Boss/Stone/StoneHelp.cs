﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoneHelp : MonoBehaviour
{
    public List<GameObject> posList = new List<GameObject>();
    [HideInInspector] public bool onoff;

    private void Awake()
    {
        onoff = false;
    }

    private void Update()
    {
        if(onoff)
        {
            int count = ObjectPool.GetInstance().stoneListCount;

            for (int i=0; i < posList.Count-1; i++)
            {
                ObjectPool.GetInstance().stone[count].SetActive(true);
                ObjectPool.GetInstance().stone[count].transform.position = posList[i].transform.position;
                count = ObjectPool.GetInstance().countAdd(ObjectPool.GetInstance().stone.Count, count);
            }
            onoff = false;
        }
        else if(!onoff)
        {

        }
    }
}
