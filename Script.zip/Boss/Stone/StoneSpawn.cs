﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoneSpawn : MonoBehaviour
{
    public StoneHelp help;

    int count;
    bool start = false;
    // Start is called before the first frame update
    void Start()
    {
    }

    private void Update()
    {
        if (help.onoff && start)
        {
            //오브젝트가 켜져있으면 ++해준다??
            count = ObjectPool.GetInstance().stoneListCount;
            for (; ; )
            {
                if (ObjectPool.GetInstance().stone[count].active == true)
                    count = ObjectPool.GetInstance().countAdd(ObjectPool.GetInstance().stone.Count, count);
                else if (ObjectPool.GetInstance().stone[count].active == false)
                    break;
            }
            ObjectPool.GetInstance().stone[count].SetActive(true);
            ObjectPool.GetInstance().stone[count].transform.position = this.transform.position;

            ObjectPool.GetInstance().countAdd(ObjectPool.GetInstance().stone.Count, count);


            start = false;
        }
        else if(!help.onoff)
        {
            start = true;
        }
    }
}
