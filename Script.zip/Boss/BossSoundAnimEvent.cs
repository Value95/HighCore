﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossSoundAnimEvent : MonoBehaviour
{
    public void MoveSound()
    {
        Boss_SoundManage.GetInstance().Boss_Move_Sound();
    }

    public void LodingSound()
    {
        Boss_SoundManage.GetInstance().Boss_LodingSound();
    }

    public void Poisongas_ShotSound()
    {
        Boss_SoundManage.GetInstance().Boss_Poisongas_ShotSound();
    }

    public void RoarSound()
    {
        Boss_SoundManage.GetInstance().Boss_RoarSound();
    }

    public void CutSound(int num)
    {
        Boss_SoundManage.GetInstance().Boss_CutSound(num);
    }

    public void PierceSound()
    {
        Boss_SoundManage.GetInstance().Boss_PierceSound();
    }

    public void DeathSound()
    {
        Boss_SoundManage.GetInstance().Boss_DeathSound();
    }

    public void DeathExplosionSound()
    {
        Boss_SoundManage.GetInstance().Boss_DeathExplosionSound();
    }

    public void PageChangeSound()
    {
        Boss_SoundManage.GetInstance().Boss_PageChangeSound();
    }
}
