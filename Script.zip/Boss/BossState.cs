﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossState : MonoBehaviour
{
    public float poisonDamage; // 독대미지
    public float poisonTimer; // 이동시간

    public float thornTimer; // 가시타이머

    public float cutDamage; // 컷대미지
    public float cutCount; // 맞은횟수

    public float pierceDamage; // 찍기대미지
    public float pierceTimer; // 찍가티이머

    public float posChangeTimer;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
