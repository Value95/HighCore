﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;

public struct Timer
{
    public float PoisonGas; // 독가스
    public float Thorn;
    public float Pierce;
    public float PosChange;
}

public enum Boss_State
{
    Idle,
    PosChange,
    PoisonGas,
    Thorn,
    PageChange,
    Roar,
    Cut,
    Pierce,
    Explosion,
    Damaged,
    Death
}
/// <summary>
///  위치변경
///  독가스
///  가시던지기
///  페이지변환
///  표호
///  배기
///  찍기
/// </summary>

[RequireComponent(typeof(Boss_State))]
public class BossFsm : MonoBehaviour
{

    private bool _isinit = false;
    Boss_State startState = Boss_State.Idle;

    public Dictionary<Boss_State, BossFSMState> _states = new Dictionary<Boss_State, BossFSMState>(); 

    private Boss_State currentState;
    public Boss_State _CurrentState { get { return currentState; } }

    [HideInInspector] public BossState state;
    [HideInInspector] public HP hp;
    [HideInInspector] public Animator anim;

    [HideInInspector] public int bossPage;

    public GameObject player;
    [HideInInspector] public PlayerMove playerMove;
    [HideInInspector] public PlayerFSM playerFsm;
    [HideInInspector] public bool playerGroundCheck;

    [HideInInspector] public int damagedCount; // 맞은횟수를 카운팅한다.

    public List<StoneHelp> stoneBlock = new List<StoneHelp>();
    [HideInInspector] public int posNumber;

    float oldHp;

    Timer mainTimer;
    Vector3 oldPlayerPos;

    public List<int> PageSwapHp = new List<int>();
    [HideInInspector] public List<int> PosNumberList = new List<int>();

    [HideInInspector] public List<Boss_State> patternList = new List<Boss_State>();

    bool[] damgedanim = { true, true, true, true, true, true, true, true, true, true };

    // Use this for initialization
    void Awake()
    {
        anim = transform.parent.GetComponent<Animator>();
        state = transform.GetComponent<BossState>();
        hp = transform.parent.GetComponent<HP>();
        bossPage = 1;
        posNumber = 1;
        playerGroundCheck = false;
        playerMove = player.GetComponent<PlayerMove>();
        playerFsm = player.transform.GetChild(0).GetComponent<PlayerFSM>();
        oldHp = hp.hp;


        Boss_State[] stateValues = (Boss_State[])System.Enum.GetValues(typeof(Boss_State));
        foreach (Boss_State s in stateValues)
        {
            System.Type FSMType = System.Type.GetType("Boss" + s.ToString());
            BossFSMState state = (BossFSMState)GetComponent(FSMType);
            if (null == state)
            {
                state = (BossFSMState)gameObject.AddComponent(FSMType);
            }
            _states.Add(s, state);
            state.enabled = false;
        }
    }

    void Start()
    {
        ChScript(startState);
        _isinit = true;
        TimerReset();
        oldPlayerPos = player.transform.position;
    }

    private void Update()
    {

        if (hp.hp <= 0 && currentState != Boss_State.Death)
        {
            ChScript(Boss_State.Death);
            return;
        }

        damagedCountAdd();

        Dameged();

        PageOne();

    }

    void damagedCountAdd()
    {
        if(oldHp != hp.hp)
        {
            oldHp = hp.hp;
            damagedCount++;
            Boss_SoundManage.GetInstance().Boss_HitSound();
        }
    }

    public void ChScript(Boss_State newState)
    {
        if (_isinit)
        {
            _states[currentState].enabled = false;
            _states[currentState].EndState();
        }
        currentState = newState;
        _states[currentState].BeginState();
        _states[currentState].enabled = true;
    }

    void Temp()
    {
        if(Input.GetKeyDown(KeyCode.U))
        {
            ChScript(Boss_State.Cut);
        }
        else if (Input.GetKeyDown(KeyCode.I))
        {
            ChScript(Boss_State.Damaged);
        }
        else if (Input.GetKeyDown(KeyCode.O))
        {
            ChScript(Boss_State.Explosion);
        }
        else if (Input.GetKeyDown(KeyCode.P))
        {
            ChScript(Boss_State.Pierce);
        }
        else if (Input.GetKeyDown(KeyCode.K))
        {
            ChScript(Boss_State.Roar);
        }
        else if (Input.GetKeyDown(KeyCode.L))
        {
            ChScript(Boss_State.Thorn);
        }
        else if (Input.GetKeyDown(KeyCode.J))
        {
            ChScript(Boss_State.PoisonGas);
        }
        else if (Input.GetKeyDown(KeyCode.H))
        {
            mainTimer.PosChange = state.posChangeTimer;
            patternList.Add(Boss_State.PosChange);

            for (; ; )
            {
                int tempPos = Random.Range(0, 3);
                if (posNumber != tempPos)
                {
                    if(PosNumberList.Count == 0)
                    {
                        PosNumberList.Add(tempPos);
                        return;
                    }
                    else if (PosNumberList.Count != 0 && PosNumberList[PosNumberList.Count - 1] != tempPos)
                    {
                        PosNumberList.Add(tempPos);
                        return;
                    }
                }
            }
        }
        else if (Input.GetKeyDown(KeyCode.M))
        {
            ChScript(Boss_State.PageChange);
        }
    }

    void Dameged()
    {
        float tempNumber = hp.maxHp / 10;
        for (int i = 1; i < 10; i++)
        {
            if (hp.hp <= hp.maxHp - tempNumber * i && damgedanim[i])
            {
                patternList.Insert(0,Boss_State.Damaged);
                damgedanim[i] = false;
            }
        }
    }

    public void TimerReset()
    {
        mainTimer.PoisonGas = state.poisonTimer;
        mainTimer.Thorn = state.thornTimer;
        mainTimer.Pierce = state.pierceTimer;
        mainTimer.PosChange = state.posChangeTimer;
    }

    void PageOne()
    {
        //가시
        if (oldPlayerPos == player.transform.position) // 가만히있으면 타이머다운
            mainTimer.Thorn -= Time.deltaTime;
        else // 움직였으면 움직인위치 다시 검색
        {
            oldPlayerPos = player.transform.position;
            mainTimer.Thorn = state.thornTimer;
        }

        // 독가스
        if (playerGroundCheck) // 플레이어가 땅에있으면 독가스타이머가줄어든다.
            mainTimer.PoisonGas -= Time.deltaTime;
        else if (!playerGroundCheck) // 땅을 벗어나면 타이머 초기화
            mainTimer.PoisonGas = state.poisonTimer;

        //찍기
        mainTimer.Pierce -= Time.deltaTime;
        //위치이동
        mainTimer.PosChange -= Time.deltaTime;

        // cut
        if (damagedCount >= state.cutCount)
        {
            damagedCount = 0;
            patternList.Add(Boss_State.Cut);
        }
        // 가시
        else if (mainTimer.Thorn <= 0) 
        {
            patternList.Add(Boss_State.Thorn);
            mainTimer.Thorn = state.thornTimer;
        }
        //독가스
        else if (mainTimer.PoisonGas <= 0)
        {
            int tempPos = Random.Range(0, 3);
            int[] tempPosArray = new int[3];

            for(int i=0; i < tempPosArray.Length; i++)
            {
                for (int j = 0; j < i ; j++)
                {
                    if(tempPosArray[j] == tempPos)
                    {
                        tempPos = Random.Range(0, 3);
                        j = -1;
                    }
                }
                tempPosArray[i] = tempPos;
            }

            patternList.Add(Boss_State.PosChange);
            PosNumberList.Add(tempPosArray[0]);
            patternList.Add(Boss_State.PoisonGas);

            patternList.Add(Boss_State.PosChange);
            PosNumberList.Add(tempPosArray[1]);
            patternList.Add(Boss_State.PoisonGas);

            patternList.Add(Boss_State.PosChange);
            PosNumberList.Add(tempPosArray[2]);
            patternList.Add(Boss_State.PoisonGas);

            mainTimer.PoisonGas = state.poisonTimer;
        }
        // 찍기
        else if (mainTimer.Pierce <= 0) 
        {
            patternList.Add(Boss_State.Pierce);
            mainTimer.Pierce = state.pierceTimer;
        }
        // 위치이동
        else if (mainTimer.PosChange <= 0)
        {
            mainTimer.PosChange = state.posChangeTimer;
            patternList.Add(Boss_State.PosChange);

            for (; ; )
            {
                int tempPos = Random.Range(0, 3);
                if (posNumber != tempPos)
                {
                    if (PosNumberList.Count == 0)
                    {
                        PosNumberList.Add(tempPos);
                        return;
                    }
                    else if (PosNumberList.Count != 0 && PosNumberList[PosNumberList.Count - 1] != tempPos)
                    {
                        PosNumberList.Add(tempPos);
                        return;
                    }
                }
            }
        }
    }

    void PageTwo()
    {

    }
}
