﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class BossIdle : BossFSMState
{
 
    public override void BeginState()
    {
        _manager.anim.SetInteger("Fsm", (int)Boss_State.Idle);

        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    private void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        PageCh();

        PatternStart();
    }

    void PatternStart()
    {
        if (_manager.patternList.Count != 0) //리스트에 무언가있다면 실행
        {
            switch (_manager.patternList[0])
            {
                case Boss_State.Cut:
                    _manager.ChScript(Boss_State.Cut);
                    break;
                case Boss_State.Explosion:
                    _manager.ChScript(Boss_State.Explosion);
                    break;
                case Boss_State.PageChange:
                    _manager.ChScript(Boss_State.PageChange);
                    break;
                case Boss_State.Pierce:
                    _manager.ChScript(Boss_State.Pierce);
                    break;
                case Boss_State.PoisonGas:
                    _manager.ChScript(Boss_State.PoisonGas);
                    break;
                case Boss_State.PosChange:
                    _manager.posNumber = _manager.PosNumberList[0];
                    _manager.PosNumberList.RemoveAt(0);
                    _manager.ChScript(Boss_State.PosChange);
                    break;
                case Boss_State.Roar:
                    _manager.ChScript(Boss_State.Roar);
                    break;
                case Boss_State.Thorn:
                    _manager.ChScript(Boss_State.Thorn);
                    break;
                case Boss_State.Damaged:
                    _manager.ChScript(Boss_State.Damaged);
                    break;
            }
            _manager.patternList.RemoveAt(0);
        }
    }

    void PageCh()
    {
        if (_manager.hp.hp <= _manager.PageSwapHp[0] && _manager.bossPage == 1) // 2페이지
        {
            _manager.TimerReset();
            _manager.bossPage++;
            _manager.patternList.Clear();

            _manager.patternList.Add(Boss_State.PosChange);
            _manager.PosNumberList.Add(1);
            _manager.ChScript(Boss_State.PageChange);
            _manager.patternList.Clear();
        }
    }
}

// hp를 게속 판단하여 페이지를변경시켜줄아이