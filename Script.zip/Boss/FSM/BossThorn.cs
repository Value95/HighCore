﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossThorn : BossFSMState
{
    int thornCount= 0;

    public List<GameObject> thornPos = new List<GameObject>();

    public override void BeginState()
    {
        _manager.anim.SetInteger("Fsm", (int)Boss_State.Thorn);
        StartCoroutine("ThornStart");
        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).IsName("Boss_2P_Thorn"))
        {
            if (_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).normalizedTime >= 1.0f)
            {
                _manager.ChScript(Boss_State.Idle);
            }
        }
    }

    public void ThornProduction(int count, float startAngle , float angle, int posNumber) // 가시발사갯수 , 시작각도 , 가시각도 , 발사위치
    {
        for (int i = 0; i < count; i++, thornCount++)
        {
            ObjectPool.GetInstance().thornList[thornCount].transform.position = thornPos[posNumber].transform.position;
            ObjectPool.GetInstance().thornList[thornCount].transform.eulerAngles = new Vector3(0, 0, 0);
            ObjectPool.GetInstance().thornList[thornCount].transform.eulerAngles += new Vector3(0, 0, startAngle);
            startAngle += angle;
            ObjectPool.GetInstance().thornList[thornCount].SetActive(true);
            

            if (thornCount >= ObjectPool.GetInstance().thornList.Count-1)
                thornCount = 0;
        }
    }

    IEnumerator ThornStart()
    {
        yield return new WaitForSeconds(1.3f);

        Camera.main.GetComponent<CameraMove>().CameraShake(0.5f, 0.2f);
    }
}

