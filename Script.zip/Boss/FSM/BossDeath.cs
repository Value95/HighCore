﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Timeline;
using UnityEngine.Playables;

public class BossDeath : BossFSMState
{
    bool update;
    public ParticleSystem effect;

    public PlayerMove move;
    public GameObject fsm;
    public PlayerFSM playerfsm;
    public PlayerUIController ui;

    public PlayableDirector playableDirectory;
    public TimelineAsset timeLine;
    public LoadingSceneManager scene;
    public override void BeginState()
    {
        StartCoroutine("RoarStart");
        Boss_SoundManage.GetInstance().Boss_DeathSound();

        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {
        update = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (!_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).IsName("Boss_3P_Death") && !_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).IsName("Boss_Null"))
            _manager.anim.Play("Boss_3P_Death");


        if (_manager.playerMove.groundChack && update)
        {
            update = false;
            playableDirectory.Play(timeLine);
        }
    }

    IEnumerator RoarStart()
    {
        _manager.anim.SetInteger("Fsm", (int)Boss_State.Death);

        _manager.playerFsm.invincibility = true;
        playerfsm.anim.Play("Move");
        playerfsm.ChScript(Player_State.Idle);
        move.moveOn = false;
        _manager.player.transform.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.None;
        playerfsm.anim.SetFloat("Forward", 0);
        fsm.SetActive(false);
        ui.stop = false;

        _manager.anim.Play("Boss_3P_Death");
        effect.Play();

        yield return new WaitForSeconds(5.0f);
        Boss_SoundManage.GetInstance().Boss_DeathExplosionSound();
        yield return new WaitForSeconds(1.0f);
        _manager.anim.Play("Boss_Null");
        this.transform.parent.GetComponent<PolygonCollider2D>().enabled = false;
        yield return new WaitForSeconds(5.0f);
        _manager.playerFsm.state.stop = false;
        _manager.playerFsm.state.Stamina.transform.GetChild(0).gameObject.SetActive(false);
        scene.NextScene();
        _manager.playerFsm.state.Stamina.value = _manager.playerFsm.state.Stamina.maxValue;
        _manager.playerFsm.state.hp.value = _manager.playerFsm.state.hp.maxValue;
    }
}
