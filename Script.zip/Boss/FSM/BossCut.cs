﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossCut : BossFSMState
{
    bool updateStart = false;

    public override void BeginState()
    {
        StartCoroutine("CutStart");
        _manager.anim.SetInteger("Fsm", (int)Boss_State.Cut);
        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (updateStart)
        {

            if (_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).IsName("Boss_2P_Cut"))
            {
                if (_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).normalizedTime >= 1.0f)
                {
                    _manager.ChScript(Boss_State.Idle);
                }
            }
        }
    }

    IEnumerator CutStart()
    {
        yield return new WaitForSeconds(1.5f);

        updateStart = true;        
    }
}
