﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossDamaged : BossFSMState
{
    int number;

    public override void BeginState()
    {
        _manager.anim.SetInteger("Fsm", (int)Boss_State.Damaged);
        number = Random.Range(0, _manager.stoneBlock.Count);
        _manager.stoneBlock[number].onoff = true;
        base.BeginState();

    }
    public override void EndState()
    {
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).IsName("Boss_2P_Damage"))
        {
            if (_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).normalizedTime >= 1.0f)
            {
                _manager.ChScript(Boss_State.Idle);
            }
        }
    }

}