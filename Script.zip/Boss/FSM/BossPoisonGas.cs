﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossPoisonGas : BossFSMState
{
    public ParticleSystem effectGasCloud;
    public GameObject colliderBox;
    public GameObject colliderBox_1;

    bool updateStart = false;
    public override void BeginState()
    {
        StartCoroutine("PoisonGasStart");
        _manager.anim.SetInteger("Fsm", (int)Boss_State.PoisonGas);

        base.BeginState();
    }

    public override void EndState()
    {
        StopCoroutine("PoisonGasStart");
        colliderBox.SetActive(false);
        colliderBox_1.SetActive(false);
        updateStart = false;
        base.EndState();
    }


    // Update is called once per frame
    void Update()
    {
        if (updateStart)
        {
            if (_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).IsName("2PBoss_Poisongas"))
            {
                if (_manager.anim.GetCurrentAnimatorStateInfo(_manager.bossPage).normalizedTime >= 1.0f)
                {
                    EndPoisonGas();
                }
            }
        }
    }

    void EndPoisonGas()
    {
        _manager.ChScript(Boss_State.Idle);
    }

    IEnumerator PoisonGasStart()
    {
        yield return new WaitForSeconds(1.5f);

        updateStart = true;
        effectGasCloud.Play();

        yield return new WaitForSeconds(0.2f);
        colliderBox.SetActive(true);
        colliderBox_1.SetActive(true);

    }
}


