﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LazerEvent : MonoBehaviour
{
    public PlayerFSM fsm;
    public float damage;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            fsm.state.HpDown(damage);
            StartCoroutine("TrapOff");
        }
    }
    IEnumerator TrapOff()
    {
        yield return new WaitForSeconds(1.0f);
        this.gameObject.SetActive(false);
    }
}
