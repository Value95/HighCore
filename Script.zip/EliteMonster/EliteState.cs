﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EliteState : MonoBehaviour
{
    public float speed; // 기본이동속도
    public float rushSpeed; // 달려가는속도
    public float backRushSpeed; // 달려가기전 뒤로가는속도

    public float thornCoolingTimeMax;
    [HideInInspector] public float thornCoolingTime;

    public float rushCoolingTimeMax;
    [HideInInspector] public float rushCoolingTime;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void CollingTimeDown()
    {
        if(thornCoolingTime > 0)
        {
            thornCoolingTime -= Time.deltaTime;
        }

        if(rushCoolingTime > 0)
        {
            rushCoolingTime -= Time.deltaTime;
        }
    }
}
