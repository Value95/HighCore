﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EliteIdle : EliteFSMState
{

    public AudioSource eliteAudioSource;

    // 플레이어와의 거리를항시체크 거리가일정범위에들어오면 체이싱
    public float distance;
    public GameObject target;

    public bool init;

    public override void BeginState()
    {
        _manager.anim.SetInteger("FSM", (int)Elite_State.Idle + 1);
        _manager.anim.SetFloat("IdleState", 1.0f);

        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    private void Start()
    {
        init = true;
        eliteAudioSource = GetComponent<AudioSource>();
    }

    private void Update()
    {
        if (SceneManager.GetActiveScene().name != "2_Tutorial")
        {
            if (init)
                InitMove();
            else if (!init)
            {
                _manager.LookPlayer();

                if (Vector3.Distance(this.transform.position, _manager.player.transform.position) <= distance)
                {
                    _manager.ChScript(Elite_State.Chasing);
                }
            }
        }
    }

    void InitMove()
    {
        this.transform.parent.transform.position = Vector3.MoveTowards(this.transform.position, target.transform.position, _manager.state.speed * Time.deltaTime);

        if (Vector3.Distance(this.transform.position, target.transform.position) == 0)
        {
            init = false;
        }
    }

}