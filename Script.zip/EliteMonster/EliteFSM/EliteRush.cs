﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

enum UpdateState
{
    updateStart,
    updateStop,
    updateBack
}

public class EliteRush : EliteFSMState
{
    UpdateState updateStart;

    Vector3 target;

    public override void BeginState()
    {
        _manager.anim.SetInteger("FSM", (int)Elite_State.Rush);
        target = _manager.player.transform.position;
        _manager.LookPlayer(target);

        StartCoroutine("RushStart");
        base.BeginState();
    }

    public override void EndState()
    {
        updateStart = UpdateState.updateStop;
        this.transform.parent.transform.rotation = Quaternion.identity;
        this.transform.parent.transform.localScale = new Vector3(1, 1, 1);
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {
        updateStart = UpdateState.updateStop;
    }

    // Update is called once per frame
    void Update()
    {
        if (updateStart == UpdateState.updateStart)
        {
            // 타겟지점을바라보면서 날라가기
            _manager.LookPlayer(target);
            _manager.LookAt(target);

            _manager.move(_manager.state.rushSpeed, target);

            if (Vector3.Distance(target, this.transform.position) <= 0.2f)
            {
                _manager.ChScript(Elite_State.Chasing);
            }
        }
        else if(updateStart == UpdateState.updateBack)
        {
            _manager.move(_manager.state.backRushSpeed * -1, target);
        }
    }

    IEnumerator RushStart()
    {
        updateStart = UpdateState.updateStop;
        yield return new WaitForSeconds(0.5f);
        updateStart = UpdateState.updateBack;
        yield return new WaitForSeconds(0.2f);
        updateStart = UpdateState.updateStop;
        yield return new WaitForSeconds(0.5f);
        //대미지박스키기
        updateStart = UpdateState.updateStart;

       
    }
}
