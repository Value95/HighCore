﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EliteChasing : EliteFSMState
{
    public float distance;

    public override void BeginState()
    {
        _manager.anim.SetInteger("FSM", (int)Elite_State.Chasing);
        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    private void Update()
    {
        _manager.state.CollingTimeDown();
        _manager.LookPlayer();
        Move();
        Patter();
    }

    void Move()
    {
        Vector2 dir = _manager.player.transform.position - this.transform.parent.transform.position;
        dir *= -1;

        if(_manager.player.transform.position.y + 11 >= this.transform.position.y)
        {
            if (HelpEvent.GetInstance().MoveCorrection(Vector3.up, this.transform.parent.transform.position, 1.0f))
            {
                _manager.transform.parent.transform.position += Vector3.up * 3 * Time.deltaTime;
            }
        }

        // 1의값을더해주고 뺀이유는 같은거리값을사용할시 앞뒤로 왔다갔다하는 문제발생
        if (Vector3.Distance(_manager.player.transform.position, this.transform.parent.transform.position) - 1 >= distance) // 앞으로
        {
            if (HelpEvent.GetInstance().MoveCorrection(dir, this.transform.parent.transform.position, 1.0f))
            {
                _manager.anim.SetFloat("IdleState", 0.0f);
                _manager.move(_manager.state.speed, _manager.player.transform.position);
            }

        }
        else if (Vector3.Distance(_manager.player.transform.position, this.transform.parent.transform.position) < distance) // 뒤로
        {
            if (HelpEvent.GetInstance().MoveCorrection(dir, this.transform.parent.transform.position, 1.0f))
            {
                _manager.anim.SetFloat("IdleState", 1.0f);
                _manager.move(_manager.state.speed * -1, _manager.player.transform.position);
            }
        }
    }
    
    void Patter()
    {
        if(Vector3.Distance(_manager.player.transform.position, this.transform.parent.transform.position) >= distance) // 가시
        {
            if (_manager.state.thornCoolingTime <= 0)
            {
                _manager.ChScript(Elite_State.Thorn);
                _manager.state.thornCoolingTime = _manager.state.thornCoolingTimeMax;
            }
        }
        else if (Vector3.Distance(_manager.player.transform.position, this.transform.parent.transform.position) < distance) // 돌진
        {
            if (_manager.state.rushCoolingTime <= 0)
            {
                _manager.ChScript(Elite_State.Rush);
                _manager.state.rushCoolingTime = _manager.state.rushCoolingTimeMax;
            }
        }
    }

}