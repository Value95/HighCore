﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EliteDeath : EliteFSMState
{
    public float force;

    bool deastStart;

    public override void BeginState()
    {
        _manager.anim.Play("Ani_Elitemob_DeathStart");
        _manager.rigdbody.constraints = RigidbodyConstraints2D.None;
        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    private void Start()
    {
        deastStart = false;
    }

    private void Update()
    {
        //아래 땅이있는지체크
        if (!HelpEvent.GetInstance().MoveCorrection(Vector2.down, this.transform.position, 3.7f))
        {
            _manager.rigdbody.constraints = RigidbodyConstraints2D.FreezeAll;
            _manager.anim.Play("Ani_Elitemob_DeathEnd");
            StartCoroutine("DeathStart");
        }
        else
        {
            if (this.transform.rotation.y == 0 && HelpEvent.GetInstance().MoveCorrection(Vector2.right, this.transform.position, 0.8f))
            {
                this.transform.parent.transform.position += Vector3.right * force * Time.deltaTime;
            }
            else if (this.transform.rotation.y == 1 && HelpEvent.GetInstance().MoveCorrection(Vector2.left, this.transform.position, 0.8f))
            {
                this.transform.parent.transform.position += Vector3.left * force * Time.deltaTime;
            }
        }

        if (deastStart) // 알파값먹이기
        {
            Color color = this.transform.parent.transform.GetComponent<SpriteRenderer>().color;
            color.a -= (Time.deltaTime / 2);
            this.transform.parent.transform.GetComponent<SpriteRenderer>().color = color;
        }
    }

    IEnumerator DeathStart()
    {
        deastStart = true;
        this.transform.parent.transform.GetComponent<BoxCollider2D>().enabled = false;

        yield return new WaitForSeconds(2.0f);

        deastStart = false;
        this.transform.parent.transform.gameObject.SetActive(false);
    }

}