﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EliteThorn : EliteFSMState
{
    int thornCount = 0;
    public GameObject thornPos;

    Vector3 target;

    bool targetLook;
    public override void BeginState()
    {
        _manager.anim.SetInteger("FSM", (int)Elite_State.Thorn);
        target = _manager.player.transform.position;
        StartCoroutine("ThornStart");
        base.BeginState();
    }

    public override void EndState()
    {
        this.transform.parent.transform.rotation = Quaternion.identity;
        this.transform.parent.transform.localScale = new Vector3(1, 1, 1);
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {
        targetLook = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Ani_Elitemob_Thorn"))
        {
            if(targetLook) // 플레이어추적
            {
                _manager.LookPlayer(_manager.player.transform.position);

                if (this.transform.parent.transform.eulerAngles.z >= 0 && this.transform.parent.transform.eulerAngles.z <= Mathf.Abs(35))
                    _manager.ThornLookAt(_manager.player.transform.position);
            }
            else if(!targetLook) // 타겟추적
            {
                _manager.LookPlayer(target);

                if (this.transform.parent.transform.eulerAngles.z >= 0 && this.transform.parent.transform.eulerAngles.z <= Mathf.Abs(35))
                    _manager.ThornLookAt(target);
            }

            if (_manager.anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 1.0f)
            {
                ThornProduction(_manager.transform.position);
                _manager.ChScript(Elite_State.Idle);
            }
        }
    }

    public void ThornProduction(Vector3 pos) //, 가시각도 , 발사위치
    {
        ObjectPool.GetInstance().EliteThornList[thornCount].transform.position = thornPos.transform.position;
        ObjectPool.GetInstance().EliteThornList[thornCount].GetComponent<TargetMove>().target = target;
        ObjectPool.GetInstance().EliteThornList[thornCount].SetActive(true);


        if (thornCount >= ObjectPool.GetInstance().EliteThornList.Count - 1)
            thornCount = 0;
    }

    IEnumerator ThornStart()
    {
        targetLook = true;
        yield return new WaitForSeconds(1.3f);
        targetLook = false;


        Camera.main.GetComponent<CameraMove>().CameraShake(0.5f, 0.2f);
    }
}

// 가시발사만들기
// 가시가 해당지점으로가게