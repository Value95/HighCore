﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Elite_State
{
    Idle,
    Chasing,
    Damaged,
    Death,
    Rush,
    Thorn
}

[RequireComponent(typeof(Elite_State))]
public class EliteFSM : MonoBehaviour
{
    private bool isinit = false;
    Elite_State startState = Elite_State.Idle;

    private Dictionary<Elite_State, EliteFSMState> _states = new Dictionary<Elite_State, EliteFSMState>();

    private Elite_State currentState;
    public Elite_State _CurrentState { get { return currentState; } }

    [HideInInspector] public EliteState state;
    [HideInInspector] public HP hp;
    [HideInInspector] public Animator anim;
    [HideInInspector] public Rigidbody2D rigdbody;

    [HideInInspector] public GameObject player;

    bool death;
    void Awake()
    {
        state = transform.GetComponent<EliteState>();
        hp = transform.parent.GetComponent<HP>();
        player = GameObject.FindWithTag("Player");
        anim = transform.parent.GetComponent<Animator>();
        rigdbody = transform.parent.GetComponent<Rigidbody2D>();
        death = true;

        Elite_State[] stateValues = (Elite_State[])System.Enum.GetValues(typeof(Elite_State));
        foreach (Elite_State s in stateValues)
        {
            System.Type eFSMType = System.Type.GetType(" Elite" + s.ToString());
            EliteFSMState state = (EliteFSMState)GetComponent(eFSMType);
            if (null == state)
            {
                state = (EliteFSMState)gameObject.AddComponent(eFSMType);
            }
            _states.Add(s, state);
            state.enabled = false;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        ChScript(startState);
        isinit = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (currentState != Elite_State.Death)
        {
            rigdbody.constraints = RigidbodyConstraints2D.FreezeAll;
        }
        Death();
    }

    public void ChScript(Elite_State newState)
    {
        if (isinit)
        {
            _states[currentState].enabled = false;
            _states[currentState].EndState();
        }
        currentState = newState;
        _states[currentState].BeginState();
        _states[currentState].enabled = true;
    }

    void Death()
    {
        //사망
        if (currentState != Elite_State.Death)
        {
            if (hp.hp <= 0 && death)
            {
                ChScript(Elite_State.Death);
                death = false;
            }
        }
    }

    public void move(float speed, Vector3 target)
    {
        this.transform.parent.transform.position = Vector3.MoveTowards(this.transform.parent.transform.position, target, speed * Time.deltaTime);
    }

    public void LookPlayer() 
    {
        if (this.transform.position.x - player.transform.position.x <= 0)
        {
            this.transform.parent.transform.GetComponent<SpriteRenderer>().flipX = true;
        }
        else
        {
            this.transform.parent.transform.GetComponent<SpriteRenderer>().flipX = false;
        }
    }

    public void LookPlayer(Vector3 target)
    {
        if (this.transform.position.x - target.x <= 0)
        {
            this.transform.parent.transform.GetComponent<SpriteRenderer>().flipX = true;
        }
        else
        {
            this.transform.parent.transform.GetComponent<SpriteRenderer>().flipX = false;
        }
    }

    public void LookAt(Vector3 target)
    {
        Vector2 targetRot;
        targetRot.x = target.x - transform.position.x;
        targetRot.y = target.y - transform.position.y;
        float angle = -1 * Mathf.Rad2Deg * Mathf.Atan2(targetRot.x, targetRot.y) + 135; // 135  애니메이션꺽여있는각도

        if (this.transform.position.x - target.x > 0) // 왼쪽
            angle += 90;

        this.transform.parent.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
    }

    public void ThornLookAt(Vector3 target)
    {
        Vector2 targetRot;
        targetRot.x = target.x - transform.position.x;
        targetRot.y = target.y - transform.position.y;
        float angle = -1 * Mathf.Rad2Deg * Mathf.Atan2(targetRot.x, targetRot.y) + 75; // 135  애니메이션꺽여있는각도

        if (this.transform.position.x - target.x > 0) // 왼쪽
            angle += 180;

        this.transform.parent.transform.rotation = Quaternion.Lerp(this.transform.rotation, Quaternion.Euler(new Vector3(0, 0, angle)), 3 * Time.deltaTime);
    }
}
