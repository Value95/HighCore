﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterAnimEvent : MonoBehaviour
{
    public GameObject hitBox;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void AttackStart()
    {
        hitBox.SetActive(true);
        // 콜라이더 키기
    }

    void AttackEnd()
    {
        hitBox.SetActive(false);
        // 콜라이더 끄기
    }
}
