﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutieIdle : CutieFSMState
{
    public float distance;
    bool groundInit;

    public override void BeginState()
    {
        _manager.anim.SetInteger("Fsm", (int)Cutie_State.Idle+1);
        _manager.anim.SetFloat("Forward", 0);

        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {
        groundInit = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (groundInit)
        {
            _manager.anim.SetBool("Init", groundInit);

            if (_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Cutie_Appearance"))
            {
                if (_manager.anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.8f)
                {
                    groundInit = false;
                    this.transform.parent.GetComponent<BoxCollider2D>().enabled = true;
                    _manager.anim.SetBool("Init", groundInit);
                }
            }
            else if (!_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Cutie_Appearance"))
            {
                groundInit = false;
                this.transform.parent.GetComponent<BoxCollider2D>().enabled = true;
                _manager.anim.SetBool("Init", groundInit);
            }

            return;
        }

        MonsterHelp.LookPlayer(this.gameObject, _manager.player.transform.position);

        if (Vector3.Distance(this.transform.position, _manager.player.transform.position) <= distance)
        {
            _manager.ChScript(Cutie_State.Chasing);
        }
    }
}
