﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutieAttack : CutieFSMState
{
    public float distance;

    public override void BeginState()
    {
        _manager.anim.SetInteger("Fsm", (int)Cutie_State.Attack);
        _manager.anim.SetFloat("AttackSpeed", 1);
        base.BeginState();
    }

    public override void EndState()
    {
        StopCoroutine("AttackEnd");
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Vector3.Distance(this.transform.position, _manager.player.transform.position) <= distance || _manager.anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.3f)
        {
            if(_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Cutie_Attack"))
            {
                if(_manager.anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.9f)
                {
                    StartCoroutine("AttackEnd");
                }
            }
        }
        else if(Vector3.Distance(this.transform.position, _manager.player.transform.position) > distance)
        {
            if (_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("Cutie_Attack"))
            {
                _manager.anim.SetFloat("AttackSpeed", -1);
                
                if (_manager.anim.GetCurrentAnimatorStateInfo(0).normalizedTime <= 0.1f)
                {
                    _manager.ChScript(Cutie_State.Idle);
                }
            }
        }
    }

    IEnumerator AttackEnd()
    {
        yield return new WaitForSeconds(0.5f);

        this.transform.parent.transform.gameObject.SetActive(false);
    }

}
