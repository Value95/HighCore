﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CutieFSM))]
public class CutieFSMState : MonoBehaviour
{
    [HideInInspector] public CutieFSM _manager;

    void Awake()
    {
        _manager = GetComponent<CutieFSM>();
    }

    public virtual void BeginState()
    {

    }

    public virtual void EndState()
    {

    }
}
