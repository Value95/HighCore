﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// 가만히 추적 , 공격 , Damaged , 사망 
public enum Cutie_State
{
    Idle = 0,
    Chasing,
    Attack,
    Death,
    Damaged
}

[RequireComponent(typeof(Cutie_State))]
public class CutieFSM : MonoBehaviour
{

    private bool isinit = false;
    Cutie_State startState = Cutie_State.Idle;

    private Dictionary<Cutie_State, CutieFSMState> _states = new Dictionary<Cutie_State, CutieFSMState>();

    private Cutie_State currentState;
    public Cutie_State _CurrentState { get { return currentState; } }

    [HideInInspector] public CutieState state;
    [HideInInspector] public HP hp;
    [HideInInspector] public Animator anim;
    [HideInInspector] public GameObject player;
    [HideInInspector] public Rigidbody2D rigdbody;
    [HideInInspector] public BoxCollider2D boxCollider;
    public GameObject hitBox;

    [HideInInspector] public bool groundCheck;
    float oldHp;

    void Awake()
    {
        anim = this.transform.parent.transform.GetComponent<Animator>();
        state = transform.GetComponent<CutieState>();
        hp = this.transform.parent.transform.GetComponent<HP>();
        player = GameObject.FindWithTag("Player");
        rigdbody = this.transform.parent.transform.GetComponent<Rigidbody2D>();
        oldHp = hp.hp;
        boxCollider = this.transform.parent.transform.GetComponent<BoxCollider2D>();

        Cutie_State[] stateValues = (Cutie_State[])System.Enum.GetValues(typeof(Cutie_State));
        foreach (Cutie_State s in stateValues)
        {
            System.Type mFSMType = System.Type.GetType("Cutie" + s.ToString());
            CutieFSMState state = (CutieFSMState)GetComponent(mFSMType);
            if (null == state)
            {
                state = (CutieFSMState)gameObject.AddComponent(mFSMType);
            }
            _states.Add(s, state);
            state.enabled = false;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        ChScript(startState);
        isinit = true;
    }

    private void Update()
    {
     
        HpDown();

        Death();
    }

    private void FixedUpdate()
    {
        groundCheck = MonsterHelp.Ground(this.gameObject);
        Ground();
    }

    public void ChScript(Cutie_State newState)
    {
        if (isinit)
        {
            _states[currentState].enabled = false;
            _states[currentState].EndState();
        }
        currentState = newState;
        _states[currentState].BeginState();
        _states[currentState].enabled = true;
    }

    void HpDown()
    {
        if (oldHp != hp.hp)
        {
            oldHp = hp.hp;
            ChScript(Cutie_State.Damaged);
        }
    }

    void Ground()
    {
        if (groundCheck) // 지상
        {
            rigdbody.constraints = RigidbodyConstraints2D.FreezeAll;
            anim.SetBool("Ground", groundCheck);
        }
        else if (!groundCheck) // 공중
        {
            rigdbody.constraints = RigidbodyConstraints2D.None;
            anim.SetBool("Ground", groundCheck);
        }
    }

    void Death()
    {
        if (hp.hp <= 0 && currentState != Cutie_State.Death)
        {
            ChScript(Cutie_State.Death);
        }
    }
}