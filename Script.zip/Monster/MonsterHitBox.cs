﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterHitBox : MonoBehaviour
{
    public float damage;
    public MonsterType type;
    public Vector2 boxSize;
    public ParticleSystem effect;
    // Start is called before the first frame update
    void Start()
    {
    }

    private void Update()
    {
        Collider2D[] cols = Physics2D.OverlapBoxAll(this.transform.position, boxSize, transform.eulerAngles.z);

        foreach (Collider2D col in cols)
        {
            if (col.transform.tag == "Player")
            {
                col.transform.GetChild(0).transform.GetComponent<PlayerState>().HpDown(damage);
                this.gameObject.SetActive(false);

                if (col.transform.GetChild(0).transform.GetComponent<PlayerFSM>().invincibility)
                {
                    switch (type)
                    {
                        case MonsterType.BBojjak:
                            effect.Play();
                            break;
                        case MonsterType.Cutie:
                            effect.Play();
                            break;
                    }
                }
            }

           
        }
    }

    void OnDrawGizmos()
    {
        Gizmos.matrix = transform.localToWorldMatrix;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(Vector3.zero, boxSize);
    }
}
