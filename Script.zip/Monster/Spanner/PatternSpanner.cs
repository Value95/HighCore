﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PatternSpanner : MonoBehaviour
{
    public float timer;
    public List<GameObject> monsterList = new List<GameObject>();

    [HideInInspector] public bool on;
    // Start is called before the first frame update
    void Start()
    {
        on = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (on)
        {
            timer -= Time.deltaTime;
            if (timer <= 0)
            {
                Spanner();
            }
        }
    }

    void Spanner()
    {
        for(int i=0; i < monsterList.Count; i++)
        {
            monsterList[i].SetActive(true);
        }
        on = false;
    }
}
