﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EggSpannerManager : MonoBehaviour
{
    public List<EggSpanner> spannerList = new List<EggSpanner>();
    float spannerTimer;
    public float spannerTimerMax;


    // Start is called before the first frame update
    void Start()
    {
        spannerTimer = spannerTimerMax;
    }

    // Update is called once per frame
    void Update()
    {
        spannerTimer -= Time.deltaTime;

        if (spannerTimer <= 0)
        {
            
        }
    }
    
}
