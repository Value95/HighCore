﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static ObjectPool;

public enum MonsterType
{
    BBojjak,
    Cutie,
    Elite
}

public class EggSpanner : MonoBehaviour
{
    public GameObject boss;
    MonsterType monsterType;
    public BossFsm fsm;
    float timer;
    public float timerMax;
    public ParticleSystem effect;
    public GameObject monsterObj;
    public List<GameObject> mon = new List<GameObject>();
    Animator anim;
    bool init;
    bool endinit;
    // Start is called before the first frame update
    void Start()
    {
        timer = timerMax;
        Rendom();
        anim = GetComponent<Animator>();
        init = true;
        endinit = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (boss.active == false)
            return;

        if (fsm.bossPage == 1)
        {
            if (init)
            {
                anim.Play("Ani_Egg_Spawner");
                init = false;
            }

            if (monsterObj == null)
                return;

            if (monsterObj.active == false)
            {
                timer -= Time.deltaTime;
                if (timer <= 0)
                {
                    anim.Play("Ani_Egg_Spawner");
                    timer = timerMax;
                }
            }
            else if(monsterObj.active == true)
            {
                if(fsm._CurrentState == Boss_State.Death && endinit)
                {
                    monsterObj.GetComponent<HP>().HpDown(9999);
                    timer = 99999999;
                    endinit = false;
                }
            }
        }
    }

    void MonsterSpawn()
    {
        switch(monsterType)
        {
            case MonsterType.BBojjak:
                BBojjak();
                break;
            case MonsterType.Cutie:
                Cutie();
                break;
        }
        Rendom();
    }

    void Rendom()
    {
        int num = Random.Range(0, 2);
        switch(num)
        {
            case 0:
                monsterType = MonsterType.BBojjak;
                break;
            case 1:
                monsterType = MonsterType.Cutie;
                break;
        }
    }

    void BBojjak()
    {
        effect.Play();
        if(monsterObj)
            Destroy(monsterObj);
        monsterObj = Instantiate(mon[0], this.transform.position, Quaternion.identity);
    }

    void Cutie()
    {
        effect.Play();
        if (monsterObj)
            Destroy(monsterObj);
        monsterObj = Instantiate(mon[1], this.transform.position, Quaternion.identity);
    }
}


// 해당위치에 한마리를