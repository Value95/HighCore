﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BBojjakDeath : BBojjakFSMState
{

    public override void BeginState()
    {
        _manager.anim.SetInteger("Fsm", (int)BBojjak_State.Death);
        _manager.anim.Play("BBojjak_Death");
        _manager.boxCollider.enabled = false;
        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("BBojjak_Death"))
            _manager.anim.Play("BBojjak_Death");

        if (_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("BBojjak_Death"))
        {
            Color color = this.transform.parent.transform.GetComponent<SpriteRenderer>().color;
            color.a -= (Time.deltaTime / 2);
            this.transform.parent.transform.GetComponent<SpriteRenderer>().color = color;

            if (_manager.anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 1.0f)
            {
                EndDeath();
            }
        }
    }


    void EndDeath()
    {
        this.transform.parent.gameObject.SetActive(false);
        _manager.boxCollider.enabled = true;
        Color color = this.transform.parent.transform.GetComponent<SpriteRenderer>().color;
        color.a = 255;
        this.transform.parent.transform.GetComponent<SpriteRenderer>().color = color;
    }
}
