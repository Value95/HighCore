﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BBojjakAttack : BBojjakFSMState
{
    public GameObject tempBox;
    public float Jump;
    public float upSpeed;
    public ParticleSystem effect;
    public ParticleSystem effect_1;
    Vector3 target;
    Vector3 attackPos;
    Vector3 upPos;

    bool upOn;
    public override void BeginState()
    {
        _manager.anim.SetInteger("Fsm", (int)BBojjak_State.Attack);
        _manager.rigdbody.constraints = RigidbodyConstraints2D.FreezeAll;
        upPos = _manager.transform.position;
        upPos.y = Jump;
        target = _manager.player.transform.position;
        upOn = true;
        effect_1.Play();
        _manager.timer = _manager.state.attackDelay;
        base.BeginState();
    }

    public override void EndState()
    {
        _manager.rigdbody.constraints = RigidbodyConstraints2D.None;
        tempBox.SetActive(false);
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (upOn)
        {
            Up();
        }
        else if (!upOn)
        {
            MonsterHelp.move(this.gameObject, _manager.state.attackSpeed, target);
            MonsterHelp.LookPlayer(this.gameObject, target);

            if (Vector3.Distance(this.transform.position, target) <= 0.2f || Vector3.Distance(this.transform.position, attackPos) <= _manager.state.attackRange)
            {
                _manager.ChScript(BBojjak_State.Idle);
            }
        }
    }

    void Up()
    {
        this.transform.parent.transform.position = Vector3.Lerp(this.transform.parent.transform.position, upPos, upSpeed * Time.deltaTime);

        if(Vector3.Distance(this.transform.position, upPos) <= 0.5f)
        {
            tempBox.SetActive(true);
            upOn = false;
            attackPos = _manager.player.transform.position;
        }
    }
    
}
