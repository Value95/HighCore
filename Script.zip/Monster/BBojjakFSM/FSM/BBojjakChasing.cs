﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BBojjakChasing : BBojjakFSMState
{
    public float distance;

    public override void BeginState()
    {
        _manager.anim.SetInteger("Fsm", (int)BBojjak_State.Chasing);
        _manager.anim.SetFloat("Forward", 1);
        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        _manager.timer -= Time.deltaTime;

        if (_manager.groundCheck)
        {
            Vector3 tempPlayerPos = _manager.player.transform.position;
            tempPlayerPos.y = this.transform.position.y;
            MonsterHelp.move(this.gameObject, _manager.state.speed, tempPlayerPos);
            MonsterHelp.LookPlayer(this.gameObject, _manager.player.transform.position);

            if (Vector3.Distance(this.transform.position, _manager.player.transform.position) <= distance && _manager.timer <= 0)
            {
                _manager.ChScript(BBojjak_State.Attack);
            }
        }
    }
}
