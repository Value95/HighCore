﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BBojjakDamaged : BBojjakFSMState
{
    public float upForce;
    float Timer;
    public override void BeginState()
    {
        MonsterHelp.LookPlayer(this.gameObject, _manager.player.transform.position);
        _manager.anim.SetInteger("Fsm", (int)BBojjak_State.Damaged);
        _manager.anim.Play("BBojjak_Damaged");
        upper();
        Timer = 3.0f;
        base.BeginState();
    }

    public override void EndState()
    {
        base.EndState();
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Timer -= Time.deltaTime;
        if (Timer <= 0)
        {
            _manager.ChScript(BBojjak_State.Idle);
            return;
        }
        if (_manager.groundCheck)
        {
            if (_manager.anim.GetCurrentAnimatorStateInfo(0).IsName("BBojjak_Damaged"))
            {
                if (_manager.anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.9f)
                {
                    _manager.ChScript(BBojjak_State.Idle);
                    return;
                }
            }

            if (SceneManager.GetActiveScene().name != "2_Tutorial")
            {
                if (!this.transform.parent.transform.GetComponent<SpriteRenderer>().flipX && HelpEvent.GetInstance().MoveCorrection(Vector2.right, this.transform.position, 0.8f))
                {
                    this.transform.parent.transform.position += Vector3.right * _manager.state.backSpeed * Time.deltaTime;
                }
                else if (this.transform.parent.transform.GetComponent<SpriteRenderer>().flipX && HelpEvent.GetInstance().MoveCorrection(Vector2.left, this.transform.position, 0.8f))
                {
                    this.transform.parent.transform.position += Vector3.left * _manager.state.backSpeed * Time.deltaTime;
                }
            }

           
        }
            
    }

    void upper()
    {
        if (!_manager.groundCheck)
        {
            _manager.rigdbody.velocity = new Vector3(0, upForce, 0);
        }
    }
}
