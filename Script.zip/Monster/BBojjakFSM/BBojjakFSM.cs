﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// 가만히 추적 , 공격 , Damaged , 사망 
public enum BBojjak_State
{
    Idle = 0,
    Chasing,
    Attack,
    Death,
    Damaged
}

[RequireComponent(typeof(BBojjak_State))]
public class BBojjakFSM : MonoBehaviour
{

    private bool isinit = false;
    BBojjak_State startState = BBojjak_State.Idle;

    private Dictionary<BBojjak_State, BBojjakFSMState> _states = new Dictionary<BBojjak_State, BBojjakFSMState>();

    private BBojjak_State currentState;
    public BBojjak_State _CurrentState { get { return currentState; } }

    [HideInInspector] public BBojjakState state;
    [HideInInspector] public HP hp;
    [HideInInspector] public Animator anim;
    [HideInInspector] public GameObject player;
    [HideInInspector] public Rigidbody2D rigdbody;
    [HideInInspector] public BoxCollider2D boxCollider;

    [HideInInspector] public bool groundCheck;
    float oldHp;
    [HideInInspector] public float timer;

    void Awake()
    {
        anim = this.transform.parent.transform.GetComponent<Animator>();
        state = transform.GetComponent<BBojjakState>();
        hp = this.transform.parent.transform.GetComponent<HP>();
        player = GameObject.FindWithTag("Player");
        rigdbody = this.transform.parent.transform.GetComponent<Rigidbody2D>();
        oldHp = hp.hp;
        boxCollider = this.transform.parent.transform.GetComponent<BoxCollider2D>();
        timer = 0;
        BBojjak_State[] stateValues = (BBojjak_State[])System.Enum.GetValues(typeof(BBojjak_State));
        foreach (BBojjak_State s in stateValues)
        {
            System.Type mFSMType = System.Type.GetType("BBojjak" + s.ToString());
            BBojjakFSMState state = (BBojjakFSMState)GetComponent(mFSMType);
            if (null == state)
            {
                state = (BBojjakFSMState)gameObject.AddComponent(mFSMType);
            }
            _states.Add(s, state);
            state.enabled = false;
        }
    }

    // Start is called before the first frame update
    void Start()
    {

        ChScript(startState);
        isinit = true;
    }

    private void Update()
    {
        HpDown();

        Death();
    }

    private void FixedUpdate()
    {
        if (currentState != BBojjak_State.Attack)
        {
            groundCheck = MonsterHelp.Ground(this.gameObject);
            Ground();
        }
    }

    public void ChScript(BBojjak_State newState)
    {
        if (isinit)
        {
            _states[currentState].enabled = false;
            _states[currentState].EndState();
        }
        currentState = newState;
        _states[currentState].BeginState();
        _states[currentState].enabled = true;
    }

    void HpDown()
    {
        if (oldHp != hp.hp)
        {
            oldHp = hp.hp;
            ChScript(BBojjak_State.Damaged);
        }
    }

    void Ground()
    {
        if(groundCheck) // 지상
        {
            rigdbody.constraints = RigidbodyConstraints2D.FreezeAll;
            anim.SetBool("Ground", groundCheck);
        }
        else if(!groundCheck) // 공중
        {
            rigdbody.constraints = RigidbodyConstraints2D.None;
            anim.SetBool("Ground", groundCheck);
        }
    }

    void Death()
    {
        if (hp.hp <= 0 && currentState != BBojjak_State.Death)
        {
            ChScript(BBojjak_State.Death);
        }
    }

    void LookAt(Vector3 target)
    {
        Vector2 targetRot;
        targetRot.x = target.x - transform.position.x;
        targetRot.y = target.y - transform.position.y;
        float angle = -1 * Mathf.Rad2Deg * Mathf.Atan2(targetRot.x, targetRot.y) + 135; // 135  애니메이션꺽여있는각도

        if (this.transform.position.x - target.x > 0) // 왼쪽
            angle += 90;

        this.transform.parent.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
    }
}