﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BBojjakFSM))]
public class BBojjakFSMState : MonoBehaviour
{
    [HideInInspector] public BBojjakFSM _manager;

    void Awake()
    {
        _manager = GetComponent<BBojjakFSM>();
    }

    public virtual void BeginState()
    {

    }

    public virtual void EndState()
    {

    }
}
