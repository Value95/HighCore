﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterHelp : MonoBehaviour
{
    public static void move(GameObject pos, float speed, Vector3 target) //자기자신 , 속도 , 도착지점
    {
        pos.transform.parent.transform.position = Vector3.MoveTowards(pos.transform.parent.transform.position, target, speed * Time.deltaTime);
    }

    public static void LookPlayer(GameObject pos, Vector3 target)
    {
        if (pos.transform.position.x - target.x <= 0)
        {
            pos.transform.parent.transform.GetComponent<SpriteRenderer>().flipX = true;
        }
        else
        {
            pos.transform.parent.transform.GetComponent<SpriteRenderer>().flipX = false;
        }
    }

    public static bool Ground(GameObject pos)
    {
        float maxDistance = 0.1f;
        Vector3 rayPos = pos.transform.position;
        rayPos.y -= 1.0f;
        Debug.DrawRay(rayPos, Vector2.down * maxDistance);

        if (Physics2D.Raycast(rayPos, Vector2.down, maxDistance, (1 << 12) | (1 << 14))) // 지상이라면
        {
            return true;
        }
        else // 공중이라면
        {
            return false;
        }
    }

    public static void Airburn(GameObject obj , float force)
    {
        obj.transform.position += Vector3.up * 1;
        obj.transform.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.None;
        obj.transform.GetComponent<Rigidbody2D>().velocity = new Vector3(0, force*1.3f, 0);
        obj.transform.GetComponent<Animator>().Play("UpDamaged");
        //에어번 애니실행
    }
}
