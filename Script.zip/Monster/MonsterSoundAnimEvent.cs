﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterSoundAnimEvent : MonoBehaviour
{
    public void CutieDeathSound()
    {
        Mo_SoundManage.GetInstance().Mo_CutieDeathSound();
    }

    public void BbojjakDeathSound()
    {
        Mo_SoundManage.GetInstance().Mo_BbojjakDeathSound();
    }

    public void BbojjakAttackSound(int num)
    {
        Mo_SoundManage.GetInstance().Mo_BbojjakAttackSound(num);
    }

    public void CutiekAttackSound()
    {
        Mo_SoundManage.GetInstance().Mo_CutiekAttackSound();
    }

    public void EliteThornSound()
    {
        Mo_SoundManage.GetInstance().Mo_EliteThornSound();
    }

    public void EliteIdleSound()
    {
        Mo_SoundManage.GetInstance().Mo_EliteIdleSound();
    }

    public void EliteRushMoveSound()
    {
        Mo_SoundManage.GetInstance().Mo_EliteRushMoveSound();
    }

}
