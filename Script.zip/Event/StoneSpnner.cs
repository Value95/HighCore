﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoneSpnner : MonoBehaviour
{
    public StoneHelp stoneBlock;

    public float timerMax;
    float timer;
    // Start is called before the first frame update
    void Start()
    {
        timer = timerMax;
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if(timer <= 0)
        {
            stoneSpnner();
        }
        else
        {
            stoneBlock.onoff = false;
        }
    }

    void stoneSpnner()
    {
        stoneBlock.onoff = true;
        Boss_SoundManage.GetInstance().Boss_RoarSound();
        Camera.main.GetComponent<CameraMove>().CameraShake(2.0f, 0.5f);
        timer = timerMax;
    }
}
