﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss1Production : MonoBehaviour
{
    PatternSpanner spanner;
    public GameObject timeLine;
    public Vector3 boxSize;

    bool onoff;
    // Start is called before the first frame update
    void Start()
    {
        spanner = GetComponent<PatternSpanner>();
        onoff = false;
    }


    private void Update()
    {
        //방에 몬스터가 남아있나 확인한다.
        if (!spanner.on)
        {
            Collider2D[] cols = Physics2D.OverlapBoxAll(this.transform.position, boxSize, transform.eulerAngles.z);
            onoff = false;

            foreach (Collider2D col in cols)
            {
                if (col.transform.tag == "Monster")
                {
                    onoff = true;
                }
            }

            if (!onoff)
            {
                Invoke("TimeLineActive", 2.0f);
            }
        }
    }

    void TimeLineActive()
    {
        timeLine.SetActive(true);
    }

    void OnDrawGizmos()
    {
        Gizmos.matrix = transform.localToWorldMatrix;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(Vector3.zero, boxSize);
    }
}
