﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndArea : MonoBehaviour
{
    PatternSpanner spanner;
    public GameObject area;
    public Vector3 boxSize;
    float timer;
    bool onoff;
    // Start is called before the first frame update
    void Start()
    {
        spanner = GetComponent<PatternSpanner>();
        onoff = false;
        timer = 4.0f;
    }


    private void Update()
    {
        //방에 몬스터가 남아있나 확인한다.
        if (!spanner.on)
        {
            timer -= Time.deltaTime;

            Collider2D[] cols = Physics2D.OverlapBoxAll(this.transform.position, boxSize, transform.eulerAngles.z);
            onoff = false;

            foreach (Collider2D col in cols)
            {
                if (col.transform.tag == "Monster")
                {
                    onoff = true;
                }
            }

            if (timer >= 0)
                onoff = true;

            if(!onoff)
            {
                Invoke("AreaActive", 2.0f);
            }
        }
    }

    void AreaActive()
    {
        area.SetActive(false);
    }


    void OnDrawGizmos()
    {
        Gizmos.matrix = transform.localToWorldMatrix;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(Vector3.zero, boxSize);
    }

    
}
