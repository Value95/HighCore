﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlphaController : MonoBehaviour
{
    public List<SpriteRenderer> objList = new List<SpriteRenderer>();

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void AlphaDown()
    {
        for (int i = 0; i < objList.Count; i++)
        {
            Color color = objList[i].color;
            var alpha = color.a;
            alpha -= Time.deltaTime / 2;
            alpha = Mathf.Clamp01(alpha);
            color.a = alpha;
            objList[i].color = color;
        }
    }

    void AlphaUp()
    {
        for (int i = 0; i < objList.Count; i++)
        {
            Color color = objList[i].color;
            var alpha = color.a;
            alpha -= Time.deltaTime / 2;
            alpha = Mathf.Clamp01(alpha);
            color.a = alpha;
            objList[i].color = color;
        }
    }
}
