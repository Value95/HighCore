﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RadioEvent : MonoBehaviour
{
    public GameObject radioBox;
    public GameObject tutoMob;
    public GameObject tutoElite;
    public GameObject tutoAtkComMob;
    public GameObject tutoUpComMob;
    bool trigger3rdIn = false;  // 3번째 튜토 무전 트리거에 들어갔는지 확인하기 위한 불
    bool triggerNextScene = false;
    bool bossDeathTrigger = false;
    bool uppercutCheck = false;
    bool airAttackCheck = false;
    bool skillUseCheck = false;
    bool skillUse1st = false;
    bool skillUse2nd = false;
    bool skillUse3rd = false;
    bool doubleJumpCheck = false;
    bool healingUseCheck = false;

    float timer = 4.0f;
    float timerMax = 4.0f;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            if (gameObject.name == "TutoRadioTrigger1st")
            {
                StartCoroutine("TutoRadio1st");
            }
            else if (gameObject.name == "TutoRadioTrigger2nd")
            {
                if (GameObject.Find("TutoRadio1st") == true)
                {
                    GameObject.Find("TutoRadio1st").SetActive(false);
                    StartCoroutine("TutoRadio2nd");
                }
                else
                {
                    StartCoroutine("TutoRadio2nd");
                }
            }
            else if (gameObject.name == "TutoRadioTrigger3rd")
            {
                // 불값이 트루가 되는것을 확인
                trigger3rdIn = true;
            }
            else if (gameObject.name == "TutoNextScene")
            {
                triggerNextScene = true;
            }
            else if (gameObject.name == "CityRadioTrigger1st")
            {
                StartCoroutine("CityRadio1st");
            }
            else if (gameObject.name == "CityRadioTrigger2nd")
            {
                StartCoroutine("CityRadio2nd");
            }
            else if (gameObject.name == "BossRoomRadioTrigger1st")
            {
                StartCoroutine("BossRoomRadio1st");
            }
            else if (gameObject.name == "BossRoomRadioTrigger2nd")
            {
                if (GameObject.Find("BossRoomRadio1st") == true)
                {
                    GameObject.Find("BossRoomRadio1st").SetActive(false);
                    StartCoroutine("BossRoomRadio2nd");
                }
                else
                {
                    StartCoroutine("BossRoomRadio2nd");
                }
            }
            else if (gameObject.name == "StageClearRadioTrigger")
            {
                StartCoroutine("StageClearRadio");
            }

            else if (gameObject.name == "TutoMoveTrigger")
            {
                StartCoroutine("TutoMove");
            }
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            if (gameObject.name == "TutoJumpTrigger")
            {
                if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
                {
                    StartCoroutine("TutoJump");
                }
            }
            if (gameObject.name == "TutoAttackTrigger")
            {
                if (GameObject.Find("Player").GetComponent<PlayerMove>().groundChack == false && Input.GetKeyDown(PlayerKeyMaster.GetInstance().keyMaster[PlayerKey.Jump]))
                {
                    StartCoroutine("TutoAttack");
                }
            }
            if (gameObject.name == "TutoSkillTrigger")
            {
                if (GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("GroundAttack.Attack_2") == true && GameObject.Find("MobOutCheckSenser").GetComponent<MobOutCheck>().mobFalseCheck == true)
                {
                    StartCoroutine("TutoSkill");
                }
            }
            if (gameObject.name == "TutoUppercutTrigger")
            {
                if (Input.GetKeyUp(PlayerKeyMaster.GetInstance().keyMaster[PlayerKey.Skill]))
                {
                    skillUse1st = true;
                }
                if (skillUse1st == true && Input.GetKeyDown(PlayerKeyMaster.GetInstance().keyMaster[PlayerKey.Skill]))
                {
                    skillUse2nd = true;
                }
                if (skillUse1st && skillUse2nd && Input.GetKeyDown(PlayerKeyMaster.GetInstance().keyMaster[PlayerKey.Skill]))
                {
                    skillUse3rd = true;
                }
                if (skillUse1st && skillUse2nd && skillUse3rd)
                {
                    StartCoroutine("TutoUppercut");
                }
            }
            if (gameObject.name == "TutoAirCombo2Trigger")
            {
                if (GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Base Layer.UpperCut") == true)
                {
                    uppercutCheck = true;
                }
                else if (uppercutCheck == true)
                {
                    if (GameObject.Find("Player").GetComponent<PlayerMove>().groundChack == false && GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Attack_2") == true && GameObject.Find("MobOutCheckSenser").GetComponent<MobOutCheck>().mobFalseCheck == true)
                    {
                        StartCoroutine("TutoAirCombo2");
                    }
                }
                else if (GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Base Layer.UpperCut") == false && GameObject.Find("Player").GetComponent<PlayerMove>().groundChack == true)
                {
                    uppercutCheck = false;
                }
            }
            if (gameObject.name == "TutoAirCombo3Trigger")
            {
                if (GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("AirAttack.Attack_0") == true)
                {
                    airAttackCheck = true;
                }
                else if (GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Base Layer.DoubleJump") == true)
                {
                    doubleJumpCheck = true;
                }
                else if (airAttackCheck == true && doubleJumpCheck == true)
                {
                    if (GameObject.Find("Player").GetComponent<PlayerMove>().groundChack == false && Input.GetKeyDown(PlayerKeyMaster.GetInstance().keyMaster[PlayerKey.Attack]))
                    {
                        StartCoroutine("TutoAirCombo3");
                    }
                }
                if (GameObject.Find("Player").GetComponent<PlayerMove>().groundChack == true)
                {
                    airAttackCheck = false;
                    doubleJumpCheck = false;
                }
            }
            if (gameObject.name == "TutoHealingTrigger")
            {
                if (GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Skill"))
                {
                    if (GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.9f)
                    {
                        skillUseCheck = true;
                    }
                }
                if (GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("AirAttack.Attack_0") == true)
                {
                    airAttackCheck = true;
                }
                else if (skillUseCheck == true && airAttackCheck == true && GameObject.Find("MobOutCheckSenser").GetComponent<MobOutCheck>().mobFalseCheck == true)
                {
                    StartCoroutine("TutoHealing");
                }
                if (GameObject.Find("Player").GetComponent<PlayerMove>().groundChack == true)
                {
                    airAttackCheck = false;
                    if (airAttackCheck == false)
                    {
                        skillUseCheck = false;
                    }
                }
            }
            if (gameObject.name == "TutoGuideEndTrigger")
            {
                if (GameObject.Find("Player").GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Base Layer.Healing"))
                {
                    StartCoroutine("TutoRadio3rd");
                }
            }
        }
    }

    private void Update()
    {
        if (SceneManager.GetActiveScene().name == "2_Tutorial")
        {
            if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoJump").gameObject.activeSelf == true)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoMove").gameObject.activeSelf == true)
                {
                    GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoMove").gameObject.SetActive(false);
                }
            }
            if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAttack").gameObject.activeSelf == true)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoJump").gameObject.activeSelf == true)
                {
                    GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoJump").gameObject.SetActive(false);
                }
            }
            if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.activeSelf == true)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAttack").gameObject.activeSelf == true)
                {
                    GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAttack").gameObject.SetActive(false);
                }
            }
            if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoUppercut").gameObject.activeSelf == true)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.activeSelf == true)
                {
                    GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.SetActive(false);
                }
            }
            if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.activeSelf == true)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoUppercut").gameObject.activeSelf == true)
                {
                    GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoUppercut").gameObject.SetActive(false);
                }
            }
            if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo3").gameObject.activeSelf == true)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.activeSelf == true)
                {
                    GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.SetActive(false);
                }
            }
            if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoHealing").gameObject.activeSelf == true)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo3").gameObject.activeSelf == true)
                {
                    GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo3").gameObject.SetActive(false);
                }
            }

            if (GameObject.Find("GuideTrigger").transform.Find("TutoJumpTrigger").gameObject.activeSelf == true)
            {
                if (Input.GetKeyDown(KeyCode.Home))
                {
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoJump").gameObject.activeSelf == true)
                    {
                        return;
                    }
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoMove").gameObject.activeSelf == false)
                    {
                        StartCoroutine("RepeatTutoMove");
                    }
                    else
                    {
                        return;
                    }
                }
            }
            if (GameObject.Find("GuideTrigger").transform.Find("TutoAttackTrigger").gameObject.activeSelf == true)
            {
                if (Input.GetKeyDown(KeyCode.Home))
                {
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAttack").gameObject.activeSelf == true)
                    {
                        return;
                    }
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoJump").gameObject.activeSelf == false)
                    {
                        StartCoroutine("RepeatTutoJump");
                    }
                    else
                    {
                        return;
                    }
                }
            }
            if (GameObject.Find("GuideTrigger").transform.Find("TutoSkillTrigger").gameObject.activeSelf == true)
            {
                if (Input.GetKeyDown(KeyCode.Home))
                {
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.activeSelf == true)
                    {
                        return;
                    }
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAttack").gameObject.activeSelf == false)
                    {
                        StartCoroutine("RepeatTutoAttack");
                    }
                    else
                    {
                        return;
                    }
                }
                if (tutoMob.active == false) //몬스터가 죽었을때 다음으로안넘어간경우
                {
                    // 0.5초 뒤에 안넘어가면 다시해주자
                    timer -= Time.deltaTime;
                    if (timer <= 0)
                    {
                        StartCoroutine("RepeatTutoAttack");
                        timer = timerMax;
                    }
                    return;
                }
                else if(GameObject.Find("GuideTrigger").transform.Find("TutoSkillTrigger").gameObject.activeSelf == false)
                {
                    StopCoroutine("RepeatTutoAttack");
                    timer = timerMax;
                }
            }
            if (GameObject.Find("GuideTrigger").transform.Find("TutoUppercutTrigger").gameObject.activeSelf == true)
            {
                if (Input.GetKeyDown(KeyCode.Home))
                {
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoUppercut").gameObject.activeSelf == true)
                    {
                        return;
                    }
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.activeSelf == false)
                    {
                        StartCoroutine("RepeatTutoSkill");
                    }
                    else
                    {
                        return;
                    }
                }
            }
            if (GameObject.Find("GuideTrigger").transform.Find("TutoAirCombo2Trigger").gameObject.activeSelf == true)
            {
                if (Input.GetKeyDown(KeyCode.Home))
                {
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.activeSelf == true)
                    {
                        return;
                    }
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoUppercut").gameObject.activeSelf == false)
                    {
                        StartCoroutine("RepeatTutoUppercut");
                    }
                    else
                    {
                        return;
                    }
                }
                if (tutoMob.active == false) //몬스터가 죽었을때 다음으로안넘어간경우
                {
                    // 0.5초 뒤에 안넘어가면 다시해주자
                    timer -= Time.deltaTime;
                    if (timer <= 0)
                    {
                        StartCoroutine("RepeatTutoUppercut");
                        timer = timerMax;
                    }
                    return;
                }
                else if (GameObject.Find("GuideTrigger").transform.Find("TutoAirCombo2Trigger").gameObject.activeSelf == false)
                {
                    StopCoroutine("RepeatTutoUppercut");
                    timer = timerMax;
                }
            }
            if (GameObject.Find("GuideTrigger").transform.Find("TutoAirCombo3Trigger").gameObject.activeSelf == true)
            {
                Debug.Log("aa");    
                if (Input.GetKeyDown(KeyCode.Home))
                {
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo3").gameObject.activeSelf == true)
                    {
                        return;
                    }
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.activeSelf == false)
                    {
                        StartCoroutine("RepeatTutoAirCombo2");
                    }
                    else
                    {
                        return;
                    }
                }
        
            }
            if (GameObject.Find("GuideTrigger").transform.Find("TutoHealingTrigger").gameObject.activeSelf == true)
            {
                if (Input.GetKeyDown(KeyCode.Home))
                {
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoHealing").gameObject.activeSelf == true)
                    {
                        return;
                    }
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo3").gameObject.activeSelf == false)
                    {
                        StartCoroutine("RepeatTutoAirCombo3");
                    }
                    else
                    {
                        return;
                    }
                }

      
            }
            if (GameObject.Find("GuideTrigger").transform.Find("TutoGuideEndTrigger").gameObject.activeSelf == true)
            {
                if (Input.GetKeyDown(KeyCode.Home))
                {
                    if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoHealing").gameObject.activeSelf == false)
                    {
                        StartCoroutine("RepeatTutoHealing");
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }
    }

    IEnumerator TutoRadio1st()
    {
        yield return new WaitForSeconds(1.5f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(11.3f);
        radioBox.SetActive(false);
        GameObject.Find("GuideTrigger").transform.Find("TutoMoveTrigger").gameObject.SetActive(true);
        this.gameObject.SetActive(false);
    }
    IEnumerator TutoRadio2nd()
    {
        radioBox.SetActive(true);
        yield return new WaitForSeconds(3.2f);
        radioBox.SetActive(false);
        this.gameObject.SetActive(false);
    }
    IEnumerator TutoRadio3rd()
    {
        yield return new WaitForSeconds(1.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(6.2f);
        radioBox.SetActive(false);
        yield return new WaitForSeconds(1.0f);
        GameObject.Find("LoadScene").gameObject.transform.position = new Vector3(-108.0f, -7.5f, 0);
        this.gameObject.SetActive(false);
    }
    IEnumerator CityRadio1st()
    {
        yield return new WaitForSeconds(1.5f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(8.2f);
        radioBox.SetActive(false);
        this.gameObject.SetActive(false);
    }
    IEnumerator CityRadio2nd()
    {
        radioBox.SetActive(true);
        yield return new WaitForSeconds(4.2f);
        radioBox.SetActive(false);
        this.gameObject.SetActive(false);
    }
    IEnumerator BossRoomRadio1st()
    {
        radioBox.SetActive(true);
        yield return new WaitForSeconds(4.2f);
        radioBox.SetActive(false);
        this.gameObject.SetActive(false);
    }
    IEnumerator BossRoomRadio2nd()
    {
        radioBox.SetActive(true);
        yield return new WaitForSeconds(3.3f);
        radioBox.SetActive(false);
    }
    IEnumerator StageClearRadio()
    {
        yield return new WaitForSeconds(2.5f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(6.5f);
        radioBox.SetActive(false);
        this.gameObject.SetActive(false);
    }
    IEnumerator LoadScene()
    {
        yield return new WaitForSeconds(7.0f);
        radioBox.transform.position = new Vector3(137.0f, 13.1f, 0f);
    }

    IEnumerator TutoMove()
    {
        yield return new WaitForSeconds(1.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(3.5f);
        radioBox.SetActive(false);
        GameObject.Find("GuideTrigger").transform.Find("TutoJumpTrigger").gameObject.SetActive(true);
        this.gameObject.SetActive(false);
    }
    IEnumerator TutoJump()
    {
        yield return new WaitForSeconds(1.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(3.5f);
        radioBox.SetActive(false);
        GameObject.Find("GuideTrigger").transform.Find("TutoAttackTrigger").gameObject.SetActive(true);
        this.gameObject.SetActive(false);
    }
    IEnumerator TutoAttack()
    {
        yield return new WaitForSeconds(1.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(3.5f);
        radioBox.SetActive(false);
        tutoMob.gameObject.SetActive(true);
        GameObject.Find("GuideTrigger").transform.Find("TutoSkillTrigger").gameObject.SetActive(true);
        this.gameObject.SetActive(false);
    }
    IEnumerator TutoSkill()
    {
        yield return new WaitForSeconds(1.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(3.5f);
        radioBox.SetActive(false);
        GameObject.Find("GuideTrigger").transform.Find("TutoUppercutTrigger").gameObject.SetActive(true);
        this.gameObject.SetActive(false);
    }
    IEnumerator TutoUppercut()
    {
        yield return new WaitForSeconds(1.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(5.4f);
        radioBox.SetActive(false);
        GameObject.Find("GuideTrigger").transform.Find("TutoAirCombo2Trigger").gameObject.SetActive(true);
        GameObject.Find("Map").transform.Find("Image(KJW)").transform.Find("BBojjak(UpperCombo)").gameObject.SetActive(true);
        this.gameObject.SetActive(false);
    }
    IEnumerator TutoAirCombo2()
    {
        yield return new WaitForSeconds(1.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(5.4f);
        radioBox.SetActive(false);
        GameObject.Find("GuideTrigger").transform.Find("TutoAirCombo3Trigger").gameObject.SetActive(true);
        this.gameObject.SetActive(false);
    }
    IEnumerator TutoAirCombo3()
    {
        yield return new WaitForSeconds(1.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(5.4f);
        radioBox.SetActive(false);
        GameObject.Find("GuideTrigger").transform.Find("TutoHealingTrigger").gameObject.SetActive(true);
        GameObject.Find("Map").transform.Find("Image(KJW)").transform.Find("Elite(Tuto)").gameObject.SetActive(true);
        this.gameObject.SetActive(false);
    }
    IEnumerator TutoHealing()
    {
        yield return new WaitForSeconds(2.0f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(3.5f);
        radioBox.SetActive(false);
        GameObject.Find("DamagedEvent").transform.Find("LazerForHealingEvent").gameObject.SetActive(true);
        yield return new WaitForSeconds(0.5f);
        GameObject.Find("GuideTrigger").transform.Find("TutoGuideEndTrigger").gameObject.SetActive(true);
        yield return new WaitForSeconds(0.5f);
        GameObject.Find("DamagedEvent").transform.Find("StaminaFullTrigger").gameObject.SetActive(true);
        this.gameObject.SetActive(false);
    }

    IEnumerator RepeatTutoMove()
    {
        yield return new WaitForSeconds(1.0f);
        if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoMove").gameObject.activeSelf == false)
        {
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoMove").gameObject.SetActive(true);
            yield return new WaitForSeconds(3.5f);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoMove").gameObject.SetActive(false);
        }
    }
    IEnumerator RepeatTutoJump()
    {
        yield return new WaitForSeconds(1.0f);
        if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoJump").gameObject.activeSelf == false)
        {
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoJump").gameObject.SetActive(true);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoMove").gameObject.SetActive(false);
            yield return new WaitForSeconds(3.5f);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoJump").gameObject.SetActive(false);
        }
    }
    IEnumerator RepeatTutoAttack()
    {
        yield return new WaitForSeconds(1.0f);
        if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAttack").gameObject.activeSelf == false)
        {
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAttack").gameObject.SetActive(true);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoJump").gameObject.SetActive(false);
            yield return new WaitForSeconds(3.5f);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAttack").gameObject.SetActive(false);
            if (GameObject.Find("MobOutCheckSenser").GetComponent<MobOutCheck>().alwaysMobCheck == false)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.activeSelf == false)
                {
                    GameObject _obj = Instantiate(tutoAtkComMob) as GameObject;
                    _obj.transform.position = new Vector3(-96.5f, -7.08f, 0);
                }
            }
        }
    }
    IEnumerator RepeatTutoSkill()
    {
        yield return new WaitForSeconds(1.0f);
        if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.activeSelf == false)
        {
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.SetActive(true);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAttack").gameObject.SetActive(false);
            yield return new WaitForSeconds(3.5f);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.SetActive(false);
        }
    }
    IEnumerator RepeatTutoUppercut()
    {
        yield return new WaitForSeconds(1.0f);
        if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoUppercut").gameObject.activeSelf == false)
        {
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoUppercut").gameObject.SetActive(true);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoSkill").gameObject.SetActive(false);
            yield return new WaitForSeconds(5.4f);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoUppercut").gameObject.SetActive(false);
            if (GameObject.Find("MobOutCheckSenser").GetComponent<MobOutCheck>().alwaysMobCheck == false)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.activeSelf == false)
                {
                    GameObject _obj = Instantiate(tutoUpComMob) as GameObject;
                    _obj.transform.position = new Vector3(-96.5f, -7.08f, 0);
                }
            }
        }
    }
    IEnumerator RepeatTutoAirCombo2()
    {
        yield return new WaitForSeconds(1.0f);
        if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.activeSelf == false)
        {
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.SetActive(true);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoUppercut").gameObject.SetActive(false);
            yield return new WaitForSeconds(5.4f);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.SetActive(false);
        }
    }
    IEnumerator RepeatTutoAirCombo3()
    {
        yield return new WaitForSeconds(1.0f);
        if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo3").gameObject.activeSelf == false)
        {
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo3").gameObject.SetActive(true);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo2").gameObject.SetActive(false);
            yield return new WaitForSeconds(5.4f);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo3").gameObject.SetActive(false);
            if (GameObject.Find("MobOutCheckSenser").GetComponent<MobOutCheck>().alwaysMobCheck == false)
            {
                if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoHealing").gameObject.activeSelf == false)
                {
                    GameObject _obj = Instantiate(tutoElite) as GameObject;
                    _obj.transform.position = new Vector3(-90.79f, 5.0f, 0);
                }
            }
        }
    }
    IEnumerator RepeatTutoHealing()
    {
        yield return new WaitForSeconds(1.0f);
        if (GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoHealing").gameObject.activeSelf == false)
        {
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoHealing").gameObject.SetActive(true);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoAirCombo3").gameObject.SetActive(false);
            yield return new WaitForSeconds(3.5f);
            GameObject.Find("TutorialGuideScreen").transform.Find("Radios").transform.Find("TutoHealing").gameObject.SetActive(false);
        }
    }
}