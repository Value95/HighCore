﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutSceneAnim : MonoBehaviour
{

    public float verticalSpeed;
    public float horizontalSpeed;
    bool upMove = false;
    bool leftMove = false;
    public float upMoveTimer;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        upMoveTimer -= Time.deltaTime;
        if(upMoveTimer<0)
        {
            upMove = true;
            if(upMove == true)
            {

            }
        }
    }
}
