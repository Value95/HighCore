﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossClearRadioEvent : MonoBehaviour
{

    bool bossDeathTrigger = false;
    public GameObject radioBox;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (GameObject.Find("BossObject").transform.Find("Boss").GetComponent<HP>().hp <= 0)
        {
            bossDeathTrigger = true;
            if (bossDeathTrigger == true)
            {
                StartCoroutine("StageClearRadio");
                bossDeathTrigger = false;

            }
        }
    }

    IEnumerator StageClearRadio()
    {
        yield return new WaitForSeconds(2.5f);
        radioBox.SetActive(true);
        yield return new WaitForSeconds(6.5f);
        radioBox.SetActive(false);
        this.gameObject.SetActive(false);
    }
}
