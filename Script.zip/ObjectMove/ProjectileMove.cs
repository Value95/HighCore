﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum objType
{
    Stone,
    BossThron,
    EliteThorn
}

public class ProjectileMove : MonoBehaviour
{
    public float speed;
    public float damage;

    public GameObject effect;

    public objType type;

    // Start is called before the first frame update
    private void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.Translate(Vector3.down * speed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            BossHelpEvent.GetInstance().Damage(damage, true);

            GameObject temp = (GameObject)Instantiate(effect, this.transform.position, Quaternion.identity);
            Destroy(temp, 1.6f);
            this.gameObject.SetActive(false);

            switch(type)
            {
                case objType.Stone:
                    Boss_SoundManage.GetInstance().Boss_StoneSound(this.transform.position);
                    break;
                case objType.BossThron:
                        Boss_SoundManage.GetInstance().Boss_ShotSound(this.transform.position);
                    break;
                case objType.EliteThorn:
                    break;
            }
        }

        switch(type)
        {
            case objType.Stone:
                if (collision.gameObject.layer == 15)
                {
                    GameObject temp = (GameObject)Instantiate(effect, this.transform.position, Quaternion.identity);
                    Destroy(temp, 1.6f);

                    Boss_SoundManage.GetInstance().Boss_StoneSound(this.transform.position);
                    this.gameObject.SetActive(false);
                }
                break;
            case objType.BossThron:
                if (collision.gameObject.layer == 12 || collision.gameObject.layer == 14)
                {
                    GameObject temp = (GameObject)Instantiate(effect, this.transform.position, Quaternion.identity);
                    Destroy(temp, 0.2f);

                    Boss_SoundManage.GetInstance().Boss_ShotSound(this.transform.position);
                    this.gameObject.SetActive(false);
                }
                break;
            case objType.EliteThorn:
                break;
        }
    }

}
