﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetMove : MonoBehaviour
{
    [HideInInspector] public Vector3 target;

    public float speed;
    public float damage;

    public GameObject effect;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);
        LookAt();
        if (Vector3.Distance(this.transform.position, target) <= 0.5f)
        {
            GameObject temp = (GameObject)Instantiate(effect, this.transform.position, Quaternion.identity);
            Destroy(temp, 0.2f);
            this.gameObject.SetActive(false);
        }
    }

    void LookAt()
    {
        Vector2 targetRot;
        targetRot.x = target.x - transform.position.x;
        targetRot.y = target.y - transform.position.y;
        float angle = -1 * Mathf.Rad2Deg * Mathf.Atan2(targetRot.x, targetRot.y) + 180; // 135  애니메이션꺽여있는각도

        this.transform.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            collision.transform.GetChild(0).transform.GetComponent<PlayerState>().HpDown(damage);

            GameObject temp = (GameObject)Instantiate(effect, this.transform.position, Quaternion.identity);
            Destroy(temp, 0.2f);
            this.gameObject.SetActive(false);

            
        }
    }
}
