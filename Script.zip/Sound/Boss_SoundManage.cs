﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_SoundManage : MonoBehaviour
{
    private static Boss_SoundManage instance;
    public static Boss_SoundManage GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<Boss_SoundManage>();

            if (instance == null)
            {
                GameObject container = new GameObject("Boss_SoundManage");

                instance = container.AddComponent<Boss_SoundManage>();
            }
        }
        return instance;
    }

    private AudioSource musicPlayer;

    public List<AudioClip> boss_MoveSoundList = new List<AudioClip>();

    public List<AudioClip> boss_ThronSoundList = new List<AudioClip>();

    public List<AudioClip> boss_ShotSoundList = new List<AudioClip>();

    public List<AudioClip> boss_LodingSoundList = new List<AudioClip>();
    public List<AudioClip> boss_Poisongas_ShotSoundList = new List<AudioClip>();

    public List<AudioClip> boss_RoarSoundList = new List<AudioClip>();

    public List<AudioClip> boss_StoneSoundList = new List<AudioClip>();

    public List<AudioClip> boss_CutSoundList = new List<AudioClip>();

    public List<AudioClip> boss_HitSoundList = new List<AudioClip>();

    public List<AudioClip> boss_DestorySoundList = new List<AudioClip>();

    public List<AudioClip> boss_PierceSoundList = new List<AudioClip>();

    public List<AudioClip> boss_DeathSoundList = new List<AudioClip>();
    public List<AudioClip> boss_DeathExplosionSoundList = new List<AudioClip>();

    public List<AudioClip> boss_PageChangeSoundList = new List<AudioClip>();

    // Start is called before the first frame update
    void Start()
    {
        musicPlayer = this.GetComponent<AudioSource>();
    }

    public void Boss_Move_Sound()
    {
        musicPlayer.PlayOneShot(boss_MoveSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_ThronSound()
    {
        musicPlayer.PlayOneShot(boss_ThronSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_ShotSound(Vector3 pos)
    {
        GameObject player = GameObject.Find("Player");
        float soundValue = Vector3.Distance(pos, player.transform.position);

        if (soundValue/10 <= 1.5f)
        {
            musicPlayer.PlayOneShot(boss_ShotSoundList[Random.Range(0, boss_ShotSoundList.Count)], 0.1f);
            musicPlayer.pitch = Random.Range(1.01f, 1.10f);
        }
    }

    public void Boss_LodingSound()
    {
        musicPlayer.PlayOneShot(boss_LodingSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_Poisongas_ShotSound()
    {
        musicPlayer.PlayOneShot(boss_Poisongas_ShotSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_RoarSound()
    {
        musicPlayer.PlayOneShot(boss_RoarSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_StoneSound(Vector3 pos)
    {
        int random = Random.Range(0, 3);

        if (random == 0)
        {
            musicPlayer.PlayOneShot(boss_StoneSoundList[Random.Range(0, boss_StoneSoundList.Count)], 0.4f);
            musicPlayer.pitch = Random.Range(1.01f, 1.10f);
        }
    }

    public void Boss_CutSound(int num)
    {
        musicPlayer.PlayOneShot(boss_CutSoundList[num], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_HitSound()
    {
        int random = Random.Range(0, 10);

        if (random == 0)
        {
            musicPlayer.PlayOneShot(boss_HitSoundList[Random.Range(0, boss_HitSoundList.Count)], 0.6f);
            musicPlayer.pitch = Random.Range(1.01f, 1.10f);
        }
    }

    public void Boss_DestorySound(int num)
    {
        musicPlayer.PlayOneShot(boss_DestorySoundList[num], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_PierceSound()
    {
        musicPlayer.PlayOneShot(boss_PierceSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_DeathSound()
    {
        musicPlayer.PlayOneShot(boss_DeathSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_DeathExplosionSound()
    {
        musicPlayer.PlayOneShot(boss_DeathExplosionSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Boss_PageChangeSound()
    {
        musicPlayer.PlayOneShot(boss_PageChangeSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }
}
