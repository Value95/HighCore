﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Cha_SoundManage : MonoBehaviour
{
    private static Cha_SoundManage instance;
    public static Cha_SoundManage GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<Cha_SoundManage>();

            if (instance == null)
            {
                GameObject container = new GameObject("Cha_SoundManage");

                instance = container.AddComponent<Cha_SoundManage>();
            }
        }
        return instance;
    }

    private AudioSource musicPlayer;
    
    public List<AudioClip> cha_attackSoundList = new List<AudioClip>();
    public List<AudioClip> cha_attackVoiceSoundList = new List<AudioClip>();

    public List<AudioClip> cha_UpperCutSoundList = new List<AudioClip>();

    public List<AudioClip> cha_moveSoundList = new List<AudioClip>();

    public List<AudioClip> cha_damagedVoiceSoundList = new List<AudioClip>();

    public List<AudioClip> cha_jumpVoiceSoundList = new List<AudioClip>();

    public List<AudioClip> cha_skillVoiceSoundList = new List<AudioClip>();

    public List<AudioClip> cha_uppercutVoiceSoundList = new List<AudioClip>();

    public List<AudioClip> cha_jumpDownSoundList = new List<AudioClip>();
    public List<AudioClip> cha_jumpUpSoundList = new List<AudioClip>();

    public List<AudioClip> cha_healingSoundList = new List<AudioClip>();

    public List<AudioClip> cha_thornDamagedSoundList = new List<AudioClip>();

    // Start is called before the first frame update
    void Start()
    {
        musicPlayer = this.GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    // 케릭터 사운드
    public void Cha_AttackSound()
    {
        musicPlayer.PlayOneShot(cha_attackSoundList[Random.Range(0, cha_attackSoundList.Count)], 0.6f);
        musicPlayer.PlayOneShot(cha_attackVoiceSoundList[Random.Range(0, cha_attackVoiceSoundList.Count)], 0.4f);

        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Cha_MoveSound()
    {
        if(SceneManager.GetActiveScene().name == "3_City")
        {
            musicPlayer.PlayOneShot(cha_moveSoundList[Random.Range(0, 3)], 0.6f);
            musicPlayer.pitch = Random.Range(1.01f, 1.10f);
        }
        else if (SceneManager.GetActiveScene().name == "5_Boss_2" || SceneManager.GetActiveScene().name == "4_Boss_1")
        {
            musicPlayer.PlayOneShot(cha_moveSoundList[Random.Range(2, 5)], 0.6f);
            musicPlayer.pitch = Random.Range(1.01f, 1.10f);
        }
    }

    public void Cha_DamagedSound()
    {
        musicPlayer.PlayOneShot(cha_damagedVoiceSoundList[0], 1.5f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Cha_JumpSound()
    {
        musicPlayer.PlayOneShot(cha_jumpVoiceSoundList[0], 1.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Cha_SkillSound()
    {
        musicPlayer.PlayOneShot(cha_skillVoiceSoundList[Random.Range(0, cha_skillVoiceSoundList.Count)], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Cha_UpperCutSound()
    {
        musicPlayer.PlayOneShot(cha_UpperCutSoundList[0], 0.6f);
        musicPlayer.PlayOneShot(cha_uppercutVoiceSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Cha_JumpDownSound()
    {
        musicPlayer.PlayOneShot(cha_jumpDownSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Cha_JumpUpSound()
    {
        musicPlayer.PlayOneShot(cha_jumpUpSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Cha_HealingSound()
    {
        musicPlayer.PlayOneShot(cha_healingSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Cha_ThornDamagedSound()
    {
        musicPlayer.PlayOneShot(cha_thornDamagedSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

}
