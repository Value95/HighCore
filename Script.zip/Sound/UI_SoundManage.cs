﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_SoundManage : MonoBehaviour
{
    private static UI_SoundManage instance;
    public static UI_SoundManage GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<UI_SoundManage>();

            if (instance == null)
            {
                GameObject container = new GameObject("UI_SoundManage");

                instance = container.AddComponent<UI_SoundManage>();
            }
        }
        return instance;
    }

    private AudioSource musicPlayer;

    public List<AudioClip> UI_EnterSoundList = new List<AudioClip>();

    // Start is called before the first frame update
    void Start()
    {
        musicPlayer = this.GetComponent<AudioSource>();
    }

    public void UI_EnterSound()
    {
        musicPlayer.PlayOneShot(UI_EnterSoundList[0], 10.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

}
