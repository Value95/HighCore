﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ambienc_SoundManage : MonoBehaviour
{
    private static ambienc_SoundManage instance;
    public static ambienc_SoundManage GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<ambienc_SoundManage>();

            if (instance == null)
            {
                GameObject container = new GameObject("ambienc_SoundManage");

                instance = container.AddComponent<ambienc_SoundManage>();
            }
        }
        return instance;
    }

    private AudioSource musicPlayer;

    public List<AudioClip> ambienc_BackGroundList = new List<AudioClip>();

    // Start is called before the first frame update
    void Start()
    {
        musicPlayer = this.GetComponent<AudioSource>();
        ambienc_CaveSoundSound();
    }


    // Update is called once per frame
    void Update()
    {
        
    }

    public void ambienc_CaveSoundSound()
    {
        if (SceneManager.GetActiveScene().name == "3_City" | SceneManager.GetActiveScene().name == "2_Tutorial")
        {
            musicPlayer.PlayOneShot(ambienc_BackGroundList[1], 0.4f);
            musicPlayer.pitch = Random.Range(1.01f, 1.10f);
            musicPlayer.Play();
        }
        else if (SceneManager.GetActiveScene().name == "5_Boss_2" || SceneManager.GetActiveScene().name == "4_Boss_1")
        {
            musicPlayer.PlayOneShot(ambienc_BackGroundList[0], 0.6f);
            musicPlayer.pitch = Random.Range(1.01f, 1.10f);
            musicPlayer.Play();
        }
        
    }
}
