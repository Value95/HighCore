﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mo_SoundManage : MonoBehaviour
{
    private static Mo_SoundManage instance;
    public static Mo_SoundManage GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<Mo_SoundManage>();

            if (instance == null)
            {
                GameObject container = new GameObject("Mo_SoundManage");

                instance = container.AddComponent<Mo_SoundManage>();
            }
        }
        return instance;
    }

    private AudioSource musicPlayer;

    public List<AudioClip> Mo_HitSoundList = new List<AudioClip>();

    public List<AudioClip> Mo_CutieDeathSoundList = new List<AudioClip>();
    public List<AudioClip> Mo_BbojjakDeathSoundList = new List<AudioClip>();

    public List<AudioClip> Mo_BbojjakAttackSoundList = new List<AudioClip>();

    public List<AudioClip> Mo_BbojjakDamagedSoundList = new List<AudioClip>();

    public List<AudioClip> Mo_CutiekAttackSoundList = new List<AudioClip>();

    public List<AudioClip> Mo_CutiekDamagedSoundList = new List<AudioClip>();

    public List<AudioClip> Mo_EliteThornSoundList = new List<AudioClip>();

    public List<AudioClip> Mo_EliteIdleSoundList = new List<AudioClip>();

    public List<AudioClip> Mo_EliteRushMoveSoundList = new List<AudioClip>();

    // Start is called before the first frame update
    void Start()
    {
        musicPlayer = this.GetComponent<AudioSource>();
    }

    public void Mo_HitSound()
    {
        musicPlayer.PlayOneShot(Mo_HitSoundList[Random.Range(0, Mo_HitSoundList.Count)], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Mo_CutieDeathSound()
    {
        musicPlayer.PlayOneShot(Mo_CutieDeathSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Mo_BbojjakDeathSound()
    {
        musicPlayer.PlayOneShot(Mo_BbojjakDeathSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Mo_BbojjakAttackSound(int num)
    {
        musicPlayer.PlayOneShot(Mo_BbojjakAttackSoundList[num], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Mo_BbojjakDamagedSound()
    {
        musicPlayer.PlayOneShot(Mo_BbojjakDamagedSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Mo_CutiekAttackSound()
    {
        musicPlayer.PlayOneShot(Mo_CutiekAttackSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Mo_CutiekDamagedSound()
    {
        musicPlayer.PlayOneShot(Mo_CutiekDamagedSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Mo_EliteThornSound()
    {
        musicPlayer.PlayOneShot(Mo_EliteThornSoundList[0], 0.8f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Mo_EliteIdleSound()
    {
        musicPlayer.PlayOneShot(Mo_EliteIdleSoundList[0], 0.4f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

    public void Mo_EliteRushMoveSound()
    {
        musicPlayer.PlayOneShot(Mo_EliteRushMoveSoundList[0], 0.6f);
        musicPlayer.pitch = Random.Range(1.01f, 1.10f);
    }

}
